#' @title Cross-symbolic recurrence matrix
#' @description Create a cross-recurrence matrix based on two symbolic time series
#' @param symbols1 vector of symbols for first time series
#' @param symbols2 vector of symbols for second time series
#' @param embedding_dimension embedding dimension
#' @param time_delay time delay for embedding
#' @param window_size size of the sliding window (should be >= embedding_dimension)
#' @param recurrence_criterion function to determine recurrence (default: exact match)
#' @param distance_method when recurrence_criterion is not provided, the method to calculate distance ("hamming")
#' @param threshold threshold for distance-based recurrence
#' @return cross-recurrence matrix (logical matrix)
#' @export
cross_symbolic_recurrence_matrix <- function(symbols1, symbols2, embedding_dimension = 1, time_delay = 1,
                                             window_size = embedding_dimension,
                                             recurrence_criterion = NULL,
                                             distance_method = "hamming",
                                             threshold = 0) {
  n1 <- length(symbols1)
  n2 <- length(symbols2)
  
  if(window_size < embedding_dimension) {
    warning("Window size should be >= embedding dimension. Setting window_size = embedding_dimension.")
    window_size <- embedding_dimension
  }
  
  # Determine the effective length after embedding for each series
  effective_length1 <- n1 - (embedding_dimension - 1) * time_delay - (window_size - 1)
  effective_length2 <- n2 - (embedding_dimension - 1) * time_delay - (window_size - 1)
  
  if(effective_length1 <= 0 || effective_length2 <= 0) {
    stop("Time series too short for the chosen embedding parameters")
  }
  
  # Create state vectors for both time series
  state_vectors1 <- list()
  for(i in 1:effective_length1) {
    # Extract window starting at position i
    indices <- i + (0:(window_size-1))
    # Ensure indices are within bounds
    indices <- indices[indices <= n1]
    window <- symbols1[indices]
    
    # Create state vector
    if(embedding_dimension == 1) {
      state_vectors1[[i]] <- window
    } else {
      # Use delay embedding
      embedded_indices <- seq(1, length(window), by = time_delay)
      if(length(embedded_indices) >= embedding_dimension) {
        embedded_indices <- embedded_indices[1:embedding_dimension]
        state_vectors1[[i]] <- window[embedded_indices]
      } else {
        stop("Window size too small for the chosen embedding dimension and time delay")
      }
    }
  }
  
  state_vectors2 <- list()
  for(i in 1:effective_length2) {
    # Extract window starting at position i
    indices <- i + (0:(window_size-1))
    # Ensure indices are within bounds
    indices <- indices[indices <= n2]
    window <- symbols2[indices]
    
    # Create state vector
    if(embedding_dimension == 1) {
      state_vectors2[[i]] <- window
    } else {
      # Use delay embedding
      embedded_indices <- seq(1, length(window), by = time_delay)
      if(length(embedded_indices) >= embedding_dimension) {
        embedded_indices <- embedded_indices[1:embedding_dimension]
        state_vectors2[[i]] <- window[embedded_indices]
      } else {
        stop("Window size too small for the chosen embedding dimension and time delay")
      }
    }
  }
  
  # Prepare recurrence criterion if not provided
  if(is.null(recurrence_criterion)) {
    # Create appropriate distance function based on method
    if(distance_method == "hamming") {
      # Hamming distance: count of positions where symbols differ
      distance_fun <- function(x, y) {
        if(length(x) != length(y)) return(max(length(x), length(y)))
        sum(x != y)
      }
    } else {
      stop("Unsupported distance method: ", distance_method)
    }
    
    # Create recurrence criterion using the distance function
    recurrence_criterion <- function(x, y) {
      distance_fun(x, y) <= threshold
    }
  }
  
  # Calculate cross-recurrence matrix
  # Note: rows correspond to symbols1, columns to symbols2
  crm <- matrix(FALSE, nrow = effective_length1, ncol = effective_length2)
  
  for(i in 1:effective_length1) {
    for(j in 1:effective_length2) {
      # Handle NA values in state vectors
      if(any(is.na(state_vectors1[[i]])) || any(is.na(state_vectors2[[j]]))) {
        crm[i, j] <- FALSE  # Non-recurrence if either vector has NA
      } else {
        # Only apply recurrence criterion if neither vector has NA
        crm[i, j] <- recurrence_criterion(state_vectors1[[i]], state_vectors2[[j]])
      }
    }
  }
  
  return(crm)
}

#' @title Cross recurrence quantification analysis measures
#' @description Calculate CRQA measures from a cross-recurrence matrix
#' @param crm cross-recurrence matrix (logical matrix)
#' @param min_line_length minimum length for diagonal and vertical lines
#' @param border number of diagonals to exclude near matrix borders for TREND calculation (default: 10)
#' @return list of CRQA measures
#' @export
quant_crqa <- function(crm, min_line_length = 2, border = 10) {
  n_rows <- nrow(crm)
  n_cols <- ncol(crm)
  
  # Recurrence Rate (RR) - density of recurrence points
  # Note: For cross-recurrence, we don't exclude a diagonal since there's no LOI
  RR <- sum(crm) / (n_rows * n_cols)
  
  # Calculate diagonal line lengths
  diagonal_lengths <- c()
  # Process each diagonal (both directions)
  for(k in -(n_rows-1):(n_cols-1)) {
    if(k < 0) {
      # Diagonals above the main diagonal
      i_start <- abs(k) + 1
      i_end <- n_rows
      j_start <- 1
      j_end <- n_cols + k
    } else {
      # Diagonals below the main diagonal
      i_start <- 1
      i_end <- n_rows - k
      j_start <- k + 1
      j_end <- n_cols
    }
    
    # Extract the diagonal
    i_indices <- i_start:i_end
    j_indices <- j_start:j_end
    diag_values <- crm[cbind(i_indices, j_indices)]
    
    # Find consecutive TRUEs
    if(length(diag_values) > 0) {
      runs <- rle(diag_values)
      # Add lengths of TRUE runs
      if(any(runs$values)) {
        diagonal_lengths <- c(diagonal_lengths, runs$lengths[runs$values])
      }
    }
  }
  
  # Calculate vertical line lengths (lines in dimension 2)
  vertical_lengths <- c()
  for(j in 1:n_cols) {
    col_j <- crm[, j]
    runs <- rle(col_j)
    if(any(runs$values)) {
      vertical_lengths <- c(vertical_lengths, runs$lengths[runs$values])
    }
  }
  
  # Calculate horizontal line lengths (lines in dimension 1)
  horizontal_lengths <- c()
  for(i in 1:n_rows) {
    row_i <- crm[i, ]
    runs <- rle(row_i)
    if(any(runs$values)) {
      horizontal_lengths <- c(horizontal_lengths, runs$lengths[runs$values])
    }
  }
  
  # Calculate recurrence times in vertical direction (system 2)
  recurrence_times_vert <- c()
  for(j in 1:n_cols) {
    col_j <- crm[, j]
    
    if(any(col_j)) {
      runs <- rle(col_j)
      
      # Find the midpoints of each recurrent structure
      midpoints <- c()
      current_pos <- 1
      
      for(k in 1:length(runs$lengths)) {
        if(runs$values[k]) {
          start_pos <- current_pos
          end_pos <- current_pos + runs$lengths[k] - 1
          midpoint <- floor((start_pos + end_pos) / 2)
          midpoints <- c(midpoints, midpoint)
        }
        current_pos <- current_pos + runs$lengths[k]
      }
      
      if(length(midpoints) > 1) {
        recurrence_times_vert <- c(recurrence_times_vert, diff(midpoints))
      }
    }
  }
  
  # Calculate recurrence times in horizontal direction (system 1)
  recurrence_times_horiz <- c()
  for(i in 1:n_rows) {
    row_i <- crm[i, ]
    
    if(any(row_i)) {
      runs <- rle(row_i)
      
      # Find the midpoints of each recurrent structure
      midpoints <- c()
      current_pos <- 1
      
      for(k in 1:length(runs$lengths)) {
        if(runs$values[k]) {
          start_pos <- current_pos
          end_pos <- current_pos + runs$lengths[k] - 1
          midpoint <- floor((start_pos + end_pos) / 2)
          midpoints <- c(midpoints, midpoint)
        }
        current_pos <- current_pos + runs$lengths[k]
      }
      
      if(length(midpoints) > 1) {
        recurrence_times_horiz <- c(recurrence_times_horiz, diff(midpoints))
      }
    }
  }
  
  # Filter by minimum line length
  diagonal_lengths <- diagonal_lengths[diagonal_lengths >= min_line_length]
  vertical_lengths <- vertical_lengths[vertical_lengths >= min_line_length]
  horizontal_lengths <- horizontal_lengths[horizontal_lengths >= min_line_length]
  recurrence_times_vert <- recurrence_times_vert[recurrence_times_vert >= min_line_length]
  recurrence_times_horiz <- recurrence_times_horiz[recurrence_times_horiz >= min_line_length]
  
  # Determinism (DET) - proportion of recurrence points forming diagonal lines
  DET <- if(length(diagonal_lengths) > 0) {
    sum(diagonal_lengths) / sum(crm)
  } else {
    0
  }
  
  # Average diagonal line length (L)
  L <- if(length(diagonal_lengths) > 0) {
    mean(diagonal_lengths)
  } else {
    0
  }
  
  # Longest diagonal line (Lmax)
  Lmax <- if(length(diagonal_lengths) > 0) {
    max(diagonal_lengths)
  } else {
    0
  }
  
  # Divergence (DIV) - inverse of Lmax
  DIV <- if(Lmax > 0) {
    1 / Lmax
  } else {
    Inf
  }
  
  # Entropy of diagonal line lengths (ENTR)
  ENTR <- if(length(diagonal_lengths) > 0) {
    # Calculate histogram
    hist_diag <- table(diagonal_lengths)
    prob_diag <- hist_diag / sum(hist_diag)
    -sum(prob_diag * log(prob_diag))
  } else {
    NaN
  }
  
  # Laminarity (LAM) - proportion of recurrence points forming vertical lines
  LAM <- if(length(vertical_lengths) > 0) {
    sum(vertical_lengths) / sum(crm)
  } else {
    0
  }
  
  # Trapping time (TT) - average vertical line length
  TT <- if(length(vertical_lengths) > 0) {
    mean(vertical_lengths)
  } else {
    0
  }
  
  # Maximum vertical line length (Vmax)
  Vmax <- if(length(vertical_lengths) > 0) {
    max(vertical_lengths)
  } else {
    0
  }
  
  # Entropy of vertical line lengths (VENTR)
  VENTR <- if(length(vertical_lengths) > 0) {
    hist_vert <- table(vertical_lengths)
    prob_vert <- hist_vert / sum(hist_vert)
    -sum(prob_vert * log(prob_vert))
  } else {
    NaN
  }
  
  # CRQA-specific: Recurrence times (vertical and horizontal)
  # Average length of horizontal lines (T1)
  T1 <- if(length(horizontal_lengths) > 0) {
    mean(horizontal_lengths)
  } else {
    0
  }
  
  # Average length of vertical lines (T2)
  T2 <- if(length(vertical_lengths) > 0) {
    mean(vertical_lengths)
  } else {
    0
  }
  
  # Mean Recurrence Time for system 1 (horizontal direction)
  MRT1 <- if(length(recurrence_times_horiz) > 0) {
    mean(recurrence_times_horiz)
  } else {
    0
  }
  
  # Mean Recurrence Time for system 2 (vertical direction)
  MRT2 <- if(length(recurrence_times_vert) > 0) {
    mean(recurrence_times_vert)
  } else {
    0
  }
  
  # Recurrence Time Entropy for system 1
  RTE1 <- if(length(recurrence_times_horiz) > 0) {
    hist_rt <- table(recurrence_times_horiz)
    prob_rt <- hist_rt / sum(hist_rt)
    -sum(prob_rt * log(prob_rt))
  } else {
    NaN
  }
  
  # Recurrence Time Entropy for system 2
  RTE2 <- if(length(recurrence_times_vert) > 0) {
    hist_rt <- table(recurrence_times_vert)
    prob_rt <- hist_rt / sum(hist_rt)
    -sum(prob_rt * log(prob_rt))
  } else {
    NaN
  }
  
  # Number of Most Probable Recurrence Time for system 1
  NMPRT1 <- if(length(recurrence_times_horiz) > 0) {
    hist_rt <- table(recurrence_times_horiz)
    max(hist_rt)
  } else {
    0
  }
  
  # Number of Most Probable Recurrence Time for system 2
  NMPRT2 <- if(length(recurrence_times_vert) > 0) {
    hist_rt <- table(recurrence_times_vert)
    max(hist_rt)
  } else {
    0
  }
  
  # CRQA-specific: Recurrence ratio (ratio of recurrence points in upper vs. lower triangles)
  # This measures asymmetry between the two systems
  # Get upper and lower triangle counts (excluding diagonal)
  upper_count <- sum(crm[upper.tri(crm, diag = FALSE)])
  lower_count <- sum(crm[lower.tri(crm, diag = FALSE)])
  
  # Calculate ratio (handle case where both are 0)
  if(upper_count == 0 && lower_count == 0) {
    RR_ratio <- 1  # Equal by default
  } else if(lower_count == 0) {
    RR_ratio <- Inf  # All recurrences in upper triangle
  } else {
    RR_ratio <- upper_count / lower_count
  }
  
  # TREND - trend of recurrences
  # For cross-recurrence matrices, this is more complex due to rectangular shape
  # We'll calculate trend only if the matrix is square or near-square
  n_min <- min(n_rows, n_cols)
  
  if(n_min - border <= 0) {
    TREND <- NA
  } else {
    # Calculate trend using diagonals in the square region
    N_tilde <- n_min - border
    
    # Calculate local recurrence rate for each diagonal
    RR_d <- numeric(N_tilde)
    delta_d <- numeric(N_tilde)
    
    for(d in 1:N_tilde) {
      # Extract diagonal d
      # For cross-recurrence, start from the main diagonal (k=0)
      if(d <= n_rows && d <= n_cols) {
        i_indices <- 1:(min(n_rows, n_cols) - d + 1)
        j_indices <- d:(min(n_rows, n_cols))
        
        diag_d <- crm[cbind(i_indices, j_indices)]
        
        # Local recurrence rate for this diagonal
        RR_d[d] <- sum(diag_d) / length(diag_d)
        
        # Balanced distance measure
        delta_d[d] <- d - (N_tilde + 1) / 2
      }
    }
    
    # Calculate mean RR
    mean_RR <- mean(RR_d)
    
    # Calculate TREND using the formula
    numerator <- sum(delta_d * (RR_d - mean_RR))
    denominator <- sum(delta_d^2)
    
    if(denominator == 0) {
      TREND <- 0
    } else {
      # Factor of 1000 to express as change per 1000 data points
      TREND <- 1000 * numerator / denominator
    }
  }
  
  return(list(
    RR = RR,             # Recurrence Rate
    DET = DET,           # Determinism
    L = L,               # Average diagonal line length
    Lmax = Lmax,         # Longest diagonal line
    DIV = DIV,           # Divergence (inverse of Lmax)
    ENTR = ENTR,         # Entropy of diagonal line distribution
    LAM = LAM,           # Laminarity
    TT = TT,             # Trapping time (vertical)
    Vmax = Vmax,         # Maximum vertical line length
    VENTR = VENTR,       # Entropy of vertical line distribution
    T1 = T1,             # Average horizontal line length (system 1)
    T2 = T2,             # Average vertical line length (system 2)
    MRT1 = MRT1,         # Mean recurrence time (system 1)
    MRT2 = MRT2,         # Mean recurrence time (system 2)
    RTE1 = RTE1,         # Recurrence time entropy (system 1)
    RTE2 = RTE2,         # Recurrence time entropy (system 2)
    NMPRT1 = NMPRT1,     # Number of most probable recurrence time (system 1)
    NMPRT2 = NMPRT2,     # Number of most probable recurrence time (system 2)
    RR_ratio = RR_ratio, # Ratio of recurrences (upper/lower)
    TREND = TREND        # Trend of recurrences
  ))
}

#' @title Plot cross-recurrence plot
#' @description Create a visualization of the cross-recurrence matrix
#' @param crm cross-recurrence matrix
#' @param main plot title
#' @param col color for recurrence points (default: black)
#' @param enhanced logical, whether to use enhanced visualization with grid lines and scales
#' @param point_size size of points when using enhanced visualization
#' @param grid_col color for grid lines (enhanced = TRUE)
#' @param colormap optional color gradient function (for continuous distance matrices)
#' @param x_labels labels for x-axis (time series 2)
#' @param y_labels labels for y-axis (time series 1)
#' @param x_lab label for x-axis
#' @param y_lab label for y-axis
#' @export
plot_cross_recurrence <- function(crm, main = "Cross-Recurrence Plot", col = "black",
                                  enhanced = FALSE, point_size = 0.5, grid_col = "gray90",
                                  colormap = NULL, x_labels = NULL, y_labels = NULL,
                                  x_lab = "Time series 2", y_lab = "Time series 1") {
  n_rows <- nrow(crm)
  n_cols <- ncol(crm)
  
  # Check if the matrix is logical (binary) or numeric (distance)
  is_binary <- is.logical(crm) || (is.numeric(crm) && all(crm %in% c(0, 1)))
  
  # Set up labels if provided
  if(is.null(x_labels)) {
    x_labels <- 1:n_cols
  } else if(length(x_labels) != n_cols) {
    warning("Number of x_labels does not match cross-recurrence matrix columns")
    x_labels <- 1:n_cols
  }
  
  if(is.null(y_labels)) {
    y_labels <- 1:n_rows
  } else if(length(y_labels) != n_rows) {
    warning("Number of y_labels does not match cross-recurrence matrix rows")
    y_labels <- 1:n_rows
  }
  
  if(!enhanced) {
    # Basic visualization using image()
    if(is_binary) {
      # Binary recurrence plot
      image(1:n_cols, 1:n_rows, t(crm),  # Transpose to match conventional orientation
            col = c("white", col),
            xlab = x_lab,
            ylab = y_lab,
            main = main,
            axes = FALSE)
      
      # Add axes with proper labels
      axis(1, at = seq(1, n_cols, length.out = min(10, n_cols)),
           labels = x_labels[seq(1, n_cols, length.out = min(10, n_cols))])
      axis(2, at = seq(1, n_rows, length.out = min(10, n_rows)),
           labels = y_labels[seq(1, n_rows, length.out = min(10, n_rows))])
      box()
    } else {
      # Continuous recurrence plot (distances)
      if(is.null(colormap)) {
        # Default colormap from white to dark blue
        colormap <- grDevices::colorRampPalette(c("white", "lightblue", "blue", "darkblue"))(100)
      }
      
      image(1:n_cols, 1:n_rows, t(crm),
            col = colormap,
            xlab = x_lab,
            ylab = y_lab,
            main = main,
            axes = FALSE)
      
      # Add axes with proper labels
      axis(1, at = seq(1, n_cols, length.out = min(10, n_cols)),
           labels = x_labels[seq(1, n_cols, length.out = min(10, n_cols))])
      axis(2, at = seq(1, n_rows, length.out = min(10, n_rows)),
           labels = y_labels[seq(1, n_rows, length.out = min(10, n_rows))])
      box()
      
      # Add a color legend
      graphics::image.plot(1:n_cols, 1:n_rows, t(crm),
                           col = colormap,
                           xlab = x_lab,
                           ylab = y_lab,
                           main = main,
                           axes = FALSE)
    }
  } else {
    # Enhanced visualization using base plot
    # Set up the plot area
    plot(NA, NA, xlim = c(1, n_cols), ylim = c(1, n_rows),
         xlab = x_lab, ylab = y_lab,
         main = main, axes = FALSE)
    
    # Add grid lines
    grid_points_x <- seq(1, n_cols, by = max(1, floor(n_cols/20)))
    grid_points_y <- seq(1, n_rows, by = max(1, floor(n_rows/20)))
    abline(h = grid_points_y, col = grid_col, lty = 3)
    abline(v = grid_points_x, col = grid_col, lty = 3)
    
    # Add axes with proper labels
    axis(1, at = seq(1, n_cols, length.out = min(10, n_cols)),
         labels = x_labels[seq(1, n_cols, length.out = min(10, n_cols))])
    axis(2, at = seq(1, n_rows, length.out = min(10, n_rows)),
         labels = y_labels[seq(1, n_rows, length.out = min(10, n_rows))])
    box()
    
    if(is_binary) {
      # Plot recurrence points
      recurrence_indices <- which(crm, arr.ind = TRUE)
      if(nrow(recurrence_indices) > 0) {
        points(recurrence_indices[, 2], recurrence_indices[, 1],  # x,y coords
               pch = 15, col = col, cex = point_size)
      }
    } else {
      # For continuous recurrence plots, convert to colors
      if(is.null(colormap)) {
        # Default colormap from white to dark blue
        colormap <- grDevices::colorRampPalette(c("white", "lightblue", "blue", "darkblue"))(100)
      }
      
      # Normalize values to [0,1] for color mapping
      crm_normalized <- (crm - min(crm, na.rm = TRUE)) /
        (max(crm, na.rm = TRUE) - min(crm, na.rm = TRUE))
      
      # Convert to color indices
      color_indices <- floor(crm_normalized * (length(colormap) - 1)) + 1
      
      # Plot points with appropriate colors
      for(i in 1:n_rows) {
        for(j in 1:n_cols) {
          if(!is.na(crm[i, j]) && crm[i, j] > 0) {
            points(j, i, pch = 15,
                   col = colormap[color_indices[i, j]],
                   cex = point_size)
          }
        }
      }
      
      # Add a color legend
      # This is a simple legend - for production code, consider using a proper legend function
      legend_breaks <- seq(min(crm, na.rm = TRUE), max(crm, na.rm = TRUE), length.out = 5)
      legend_colors <- colormap[seq(1, length(colormap), length.out = length(legend_breaks))]
      legend("topright", legend = round(legend_breaks, 2),
             fill = legend_colors, title = "Distance", cex = 0.8)
    }
  }
}

#' @title Symbolize two time series for CRQA
#' @description Symbolize two time series using the same parameters for cross-recurrence analysis
#' @param ts1 first time series
#' @param ts2 second time series
#' @param method symbolization method
#' @param num_symbols number of symbols
#' @param window_size window size for sliding window methods
#' @param ... additional parameters passed to symbolize_ts
#' @return list containing the symbolized time series and parameters
#' @export
symbolize_ts_pair <- function(ts1, ts2, method = "quantiles", num_symbols = 4,
                              window_size = 3, ...) {
  if(!is.numeric(ts1) || !is.numeric(ts2)) {
    stop("Both time series must be numeric")
  }
  
  # Handle different length time series
  if(length(ts1) != length(ts2)) {
    warning("Time series have different lengths. Consider resampling to equal length.")
  }
  
  # For quantiles method, use joint distribution for consistent binning
  if(method == "quantiles") {
    # Normalize both series to 0-1 range
    ts1_norm <- (ts1 - min(ts1)) / (max(ts1) - min(ts1))
    ts2_norm <- (ts2 - min(ts2)) / (max(ts2) - min(ts2))
    
    # Combine for computing joint distribution
    ts_combined <- c(ts1_norm, ts2_norm)
    
    # Compute joint quantiles
    breaks <- stats::quantile(ts_combined, probs = seq(0, 1, length.out = num_symbols + 1),
                              na.rm = TRUE, type = 2)
    
    # Apply cut to both series, then subtract 1 to make 0-indexed
    symbols1 <- as.numeric(cut(ts1_norm, breaks = breaks, include.lowest = TRUE)) - 1
    symbols2 <- as.numeric(cut(ts2_norm, breaks = breaks, include.lowest = TRUE)) - 1
    
  } else {
    # For shape-based and ordinal methods, process each series separately
    # as they look at patterns rather than absolute values
    symbols1 <- symbolize_ts(ts1, method = method, num_symbols = num_symbols,
                             window_size = window_size, ...)
    symbols2 <- symbolize_ts(ts2, method = method, num_symbols = num_symbols,
                             window_size = window_size, ...)
  }
  
  return(list(
    symbols1 = symbols1,
    symbols2 = symbols2,
    method = method,
    num_symbols = num_symbols,
    window_size = window_size
  ))
}


#' @title Complete cross recurrence quantification analysis
#' @description Perform complete cross-RQA on two time series
#' @param ts1 first time series
#' @param ts2 second time series
#' @param method symbolization method. Options include "quantiles", "ordinal", "rle", and "categorical".
#' @param num_symbols number of symbols
#' @param window_size window size for sliding window methods
#' @param embedding_dimension embedding dimension
#' @param time_delay time delay for embedding
#' @param recurrence_criterion function to determine recurrence
#' @param distance_method method to calculate distance
#' @param threshold threshold for distance-based recurrence
#' @param min_line_length minimum length for CRQA measures
#' @param plot logical, whether to plot the cross-recurrence plot
#' @param ... additional parameters for plotting
#' @return list containing CRQA results, matrices, and parameters
#' @export
cross_rqa <- function(ts1, ts2, method = "rle", num_symbols = 8,
                      window_size = 5, embedding_dimension = 1, time_delay = 1,
                      recurrence_criterion = NULL, distance_method = "hamming",
                      threshold = 0, min_line_length = 2, plot = TRUE, ...) {
  
  # Step 1: Symbolize both time series
  symbolic_result <- symbolize_ts_pair(ts1, ts2, method = method,
                                       num_symbols = num_symbols,
                                       window_size = window_size)
  symbols1 <- symbolic_result$symbols1
  symbols2 <- symbolic_result$symbols2
  
  # Step 2: Create cross-recurrence matrix
  crm <- cross_symbolic_recurrence_matrix(
    symbols1 = symbols1,
    symbols2 = symbols2,
    embedding_dimension = embedding_dimension,
    time_delay = time_delay,
    window_size = window_size,
    recurrence_criterion = recurrence_criterion,
    distance_method = distance_method,
    threshold = threshold
  )
  
  # Step 3: Calculate CRQA measures
  crqa_measures <- quant_crqa(crm, min_line_length = min_line_length)
  
  # Step 4: Optional plotting
  if(plot) {
    plot_cross_recurrence(crm,
                          main = paste("Cross-Recurrence Plot (", method, ", symbols=", num_symbols, ")", sep=""),
                          ...)
  }
  
  # Return results
  return(list(
    crqa_measures = crqa_measures,
    crm = crm,
    symbols1 = symbols1,
    symbols2 = symbols2,
    method = method,
    num_symbols = num_symbols,
    window_size = window_size,
    embedding_dimension = embedding_dimension,
    time_delay = time_delay
  ))
}

#' @title ggplot-based cross recurrence plot
#' @description Create a cross-recurrence plot visualization using ggplot2
#' @param crm cross-recurrence matrix
#' @param title plot title
#' @param theme plot theme (light, dark, minimal, scientific, bold, void)
#' @param grid whether to show grid lines
#' @param point_size size of recurrence points
#' @param point_shape shape of recurrence points
#' @param alpha transparency of points/tiles
#' @param use_viridis which viridis colormap to use for continuous matrices
#' @param x_labels custom labels for x-axis (time series 2)
#' @param y_labels custom labels for y-axis (time series 1)
#' @param x_lab label for x-axis
#' @param y_lab label for y-axis
#' @param point_color custom color for recurrence points
#' @return ggplot object
#' @export
ggplot_cross_recurrence <- function(crm,
                                    title = "Cross Recurrence Plot",
                                    theme = "light",
                                    grid = TRUE,
                                    point_size = 1,
                                    point_shape = 15,
                                    alpha = 1,
                                    use_viridis = NULL,
                                    x_labels = NULL,
                                    y_labels = NULL,
                                    x_lab = "Time series 2",
                                    y_lab = "Time series 1",
                                    point_color = NULL) {
  
  # Ensure required packages are available
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Package 'ggplot2' is needed for this function to work. Please install it.")
  }
  
  if (!requireNamespace("reshape2", quietly = TRUE)) {
    stop("Package 'reshape2' is needed for this function to work. Please install it.")
  }
  
  # Handle NA values
  if(any(is.na(crm))) {
    warning("NA values detected in recurrence matrix. Replacing with FALSE/0.")
    if(is.logical(crm)) {
      crm[is.na(crm)] <- FALSE
    } else {
      crm[is.na(crm)] <- 0
    }
  }
  
  n_rows <- nrow(crm)
  n_cols <- ncol(crm)
  is_binary <- is.logical(crm) || (is.numeric(crm) && all(crm %in% c(0, 1)))
  
  # Create axis labels if not provided
  if(is.null(x_labels)) {
    x_labels <- 1:n_cols
  } else if(length(x_labels) != n_cols) {
    warning("Number of x_labels doesn't match matrix dimensions. Using default labels.")
    x_labels <- 1:n_cols
  }
  
  if(is.null(y_labels)) {
    y_labels <- 1:n_rows
  } else if(length(y_labels) != n_rows) {
    warning("Number of y_labels doesn't match matrix dimensions. Using default labels.")
    y_labels <- 1:n_rows
  }
  
  # Define theme-specific parameters
  theme_palettes <- list(
    light = list(
      binary_color = "#3498db",
      bg = ggplot2::theme_light() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "white"),
          plot.background = ggplot2::element_rect(fill = "white"),
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    dark = list(
      binary_color = "#3498db",
      bg = ggplot2::theme_dark() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "#222222"),
          plot.background = ggplot2::element_rect(fill = "#333333"),
          panel.grid.minor = ggplot2::element_blank(),
          plot.title = ggplot2::element_text(color = "white"),
          axis.title = ggplot2::element_text(color = "white"),
          axis.text = ggplot2::element_text(color = "white")
        )
    ),
    minimal = list(
      binary_color = "#3498db",
      bg = ggplot2::theme_minimal() +
        ggplot2::theme(
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    scientific = list(
      binary_color = "black",
      bg = ggplot2::theme_bw() +
        ggplot2::theme(
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    bold = list(
      binary_color = "#1E88E5", # Vibrant blue
      bg = ggplot2::theme_bw() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "white", color = "black", linewidth = 1.2),
          plot.background = ggplot2::element_rect(fill = "white"),
          panel.grid.major = ggplot2::element_line(color = "gray80", linewidth = 0.8),
          panel.grid.minor = ggplot2::element_blank(),
          plot.title = ggplot2::element_text(face = "bold", size = 14, hjust = 0.5),
          axis.title = ggplot2::element_text(face = "bold", size = 12),
          axis.text = ggplot2::element_text(face = "bold", size = 10),
          axis.line = ggplot2::element_line(linewidth = 1.2),
          axis.ticks = ggplot2::element_line(linewidth = 1.2)
        )
    ),
    void = list(
      binary_color = "#3498db",
      bg = ggplot2::theme_void() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = "white", color = NA),
          plot.title = ggplot2::element_text(hjust = 0.5, margin = ggplot2::margin(b = 15)),
          plot.margin = ggplot2::margin(15, 15, 10, 15),
          legend.position = "none"
        )
    )
  )
  
  # Select theme parameters
  if(!theme %in% names(theme_palettes)) {
    warning("Unknown theme '", theme, "'. Using 'light' theme.")
    theme <- "light"
  }
  tp <- theme_palettes[[theme]]
  
  # Override binary color if point_color is specified
  if(!is.null(point_color)) {
    tp$binary_color <- point_color
  }
  
  # Create the plot
  if(is_binary) {
    # For binary matrices, extract only TRUE/1 positions for efficiency
    plot_data <- which(crm == TRUE, arr.ind = TRUE)
    colnames(plot_data) <- c("y", "x")  # For correct orientation
    plot_data <- as.data.frame(plot_data)
    
    # Create plot with points
    p <- ggplot2::ggplot() +
      ggplot2::geom_point(data = plot_data,
                          ggplot2::aes(x = x, y = y),
                          color = tp$binary_color,
                          shape = point_shape,
                          size = point_size,
                          alpha = alpha)
  } else {
    # For continuous matrices, convert to long format
    plot_data <- reshape2::melt(crm)
    colnames(plot_data) <- c("y", "x", "value")
    
    # Create plot with tiles
    p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = x, y = y, fill = value)) +
      ggplot2::geom_tile(alpha = alpha)
    
    # Apply color palette based on point_color parameter, theme and viridis option
    if(!is.null(point_color)) {
      # Custom color for continuous matrices
      p <- p + ggplot2::scale_fill_gradient(low = "white", high = point_color)
    } else if(!is.null(use_viridis)) {
      p <- p + ggplot2::scale_fill_viridis_c(option = use_viridis)
    } else {
      # Default color scales by theme
      if(theme == "light") {
        p <- p + ggplot2::scale_fill_gradient(low = "white", high = "#3498db")
      } else if(theme == "dark") {
        p <- p + ggplot2::scale_fill_viridis_c(option = "viridis")
      } else if(theme == "minimal") {
        p <- p + ggplot2::scale_fill_gradient(low = "white", high = "#3498db")
      } else if(theme == "scientific") {
        p <- p + ggplot2::scale_fill_gradient(low = "white", high = "black")
      } else if(theme == "bold") {
        p <- p + ggplot2::scale_fill_gradient(low = "white", high = "#1E88E5",
                                              guide = ggplot2::guide_colorbar(
                                                frame.colour = "black",
                                                frame.linewidth = 1.2,
                                                ticks.colour = "black",
                                                ticks.linewidth = 1.2
                                              ))
      } else if(theme == "void") {
        p <- p + ggplot2::scale_fill_gradient(low = "white", high = "#3498db", guide = "none")
      }
    }
  }
  
  # Add axis labels and title
  p <- p + ggplot2::labs(
    title = title,
    x = x_lab,
    y = y_lab
  )
  
  # Apply theme and customize axes
  p <- p + tp$bg
  
  # For void theme, we skip axis customization completely
  if(theme != "void") {
    p <- p + ggplot2::theme(
      plot.title = ggplot2::element_text(hjust = 0.5),
      panel.grid.major = if(grid) ggplot2::element_line() else ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      legend.position = if(is_binary) "none" else "right"
    )
    
    # Set appropriate axis ticks
    if(n_cols <= 50 && n_rows <= 50) {
      # For small matrices, show all ticks
      p <- p + ggplot2::scale_x_continuous(breaks = 1:n_cols, labels = x_labels) +
        ggplot2::scale_y_continuous(breaks = 1:n_rows, labels = y_labels)
    } else {
      # For larger matrices, show ~10 ticks
      x_tick_count <- min(10, n_cols)
      y_tick_count <- min(10, n_rows)
      x_tick_positions <- round(seq(1, n_cols, length.out = x_tick_count))
      y_tick_positions <- round(seq(1, n_rows, length.out = y_tick_count))
      p <- p + ggplot2::scale_x_continuous(breaks = x_tick_positions,
                                           labels = x_labels[x_tick_positions]) +
        ggplot2::scale_y_continuous(breaks = y_tick_positions,
                                    labels = y_labels[y_tick_positions])
    }
    
    # Add recurrence rate as a caption
    rr <- sum(crm) / (n_rows * n_cols)
    p <- p + ggplot2::labs(caption = paste("Cross-Recurrence Rate:", round(rr, 3)))
  } else {
    # For void theme, ensure there are no axes or grid lines
    # Just add the title if specified
    if(title != "") {
      p <- p + ggplot2::labs(title = title)
    }
  }
  
  return(p)
}

#' @title Symbol color-coded cross-recurrence plot
#' @description Create a cross-recurrence plot with colors based on symbol types
#' @param symbols1 vector of symbols for first time series
#' @param symbols2 vector of symbols for second time series
#' @param embedding_dimension embedding dimension
#' @param time_delay time delay for embedding
#' @param window_size size of sliding window
#' @param title plot title
#' @param theme plot theme
#' @param grid whether to show grid lines
#' @param point_size size of recurrence points
#' @param point_shape shape of recurrence points
#' @param alpha transparency of points
#' @param symbol_colors custom colors for symbols
#' @param symbol_labels custom labels for symbols
#' @param x_labels custom labels for x-axis (time series 2)
#' @param y_labels custom labels for y-axis (time series 1)
#' @param x_lab label for x-axis
#' @param y_lab label for y-axis
#' @return ggplot object
#' @export
symbol_cross_recurrence_plot <- function(symbols1, symbols2,
                                         embedding_dimension = 1,
                                         time_delay = 1,
                                         window_size = embedding_dimension,
                                         title = "Symbol Color-Coded Cross-Recurrence Plot",
                                         theme = "light",
                                         grid = TRUE,
                                         point_size = 1,
                                         point_shape = 15,
                                         alpha = 1,
                                         symbol_colors = NULL,
                                         symbol_labels = NULL,
                                         x_labels = NULL,
                                         y_labels = NULL,
                                         x_lab = "Time series 2",
                                         y_lab = "Time series 1") {
  
  # Ensure required packages are available
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Package 'ggplot2' is needed for this function to work. Please install it.")
  }
  
  # Handle empty or invalid input
  if(is.null(symbols1) || length(symbols1) == 0 ||
     is.null(symbols2) || length(symbols2) == 0) {
    stop("Symbol vectors cannot be empty")
  }
  
  # If symbols are non-numeric vectors (e.g. character), convert to factor then numeric
  if(!is.numeric(symbols1)) {
    symbols1 <- as.numeric(as.factor(symbols1))
  }
  if(!is.numeric(symbols2)) {
    symbols2 <- as.numeric(as.factor(symbols2))
  }
  
  n1 <- length(symbols1)
  n2 <- length(symbols2)
  
  # Calculate effective length after embedding
  effective_length1 <- n1 - (embedding_dimension - 1) * time_delay
  effective_length2 <- n2 - (embedding_dimension - 1) * time_delay
  
  if(effective_length1 <= 0 || effective_length2 <= 0) {
    stop("Time series too short for the chosen embedding parameters")
  }
  
  # Create state vectors using proper embedding
  state_vectors1 <- list()
  for(i in 1:effective_length1) {
    # Create state vector with proper embedding
    if(embedding_dimension == 1) {
      state_vectors1[[i]] <- symbols1[i]
    } else {
      indices <- i + (0:(embedding_dimension-1)) * time_delay
      state_vectors1[[i]] <- symbols1[indices]
    }
  }
  
  state_vectors2 <- list()
  for(i in 1:effective_length2) {
    # Create state vector with proper embedding
    if(embedding_dimension == 1) {
      state_vectors2[[i]] <- symbols2[i]
    } else {
      indices <- i + (0:(embedding_dimension-1)) * time_delay
      state_vectors2[[i]] <- symbols2[indices]
    }
  }
  
  # Create a binary recurrence matrix (1 = match, 0 = no match)
  binary_rm <- matrix(0, nrow = effective_length1, ncol = effective_length2)
  symbol_rm <- matrix(NA, nrow = effective_length1, ncol = effective_length2)
  
  # Fill the matrix comparing embedded states
  for(i in 1:effective_length1) {
    for(j in 1:effective_length2) {
      if(embedding_dimension == 1) {
        # For single values, just check equality
        if(!is.na(state_vectors1[[i]]) && !is.na(state_vectors2[[j]]) &&
           state_vectors1[[i]] == state_vectors2[[j]]) {
          binary_rm[i, j] <- 1
          symbol_rm[i, j] <- state_vectors1[[i]]
        }
      } else {
        # For embedded vectors, check if all values match
        if(!any(is.na(state_vectors1[[i]])) && !any(is.na(state_vectors2[[j]])) &&
           all(state_vectors1[[i]] == state_vectors2[[j]])) {
          binary_rm[i, j] <- 1
          symbol_rm[i, j] <- state_vectors1[[i]][1]  # Use first symbol as identifier
        }
      }
    }
  }
  
  # Convert to data frame for plotting
  recurrence_indices <- which(binary_rm == 1, arr.ind = TRUE)
  if(nrow(recurrence_indices) == 0) {
    return(ggplot2::ggplot() +
             ggplot2::labs(title = "No recurrence points found",
                           subtitle = "Check your symbolization parameters") +
             ggplot2::theme_minimal())
  }
  
  # Create data frame for plotting
  plot_data <- data.frame(
    y = recurrence_indices[, 1],
    x = recurrence_indices[, 2],
    symbol = sapply(1:nrow(recurrence_indices), function(i) {
      row <- recurrence_indices[i, 1]
      col <- recurrence_indices[i, 2]
      return(symbol_rm[row, col])
    })
  )
  
  # Define standard shape names
  shape_names <- c(
    "Monotonic increasing",  # 0
    "Monotonic decreasing",  # 1
    "Single peak",           # 2
    "Single valley",         # 3
    "Step up",               # 4
    "Step down",             # 5
    "Oscillation up",        # 6
    "Oscillation down"       # 7
  )
  
  # Get unique symbols for coloring
  unique_symbols <- sort(unique(plot_data$symbol))
  num_symbols <- length(unique_symbols)
  
  # Create axis labels for the embedded space
  if(is.null(x_labels)) {
    x_labels <- 1:effective_length2
  } else if(length(x_labels) != effective_length2) {
    warning("Number of x_labels doesn't match effective dimensions. Using default labels.")
    x_labels <- 1:effective_length2
  }
  
  if(is.null(y_labels)) {
    y_labels <- 1:effective_length1
  } else if(length(y_labels) != effective_length1) {
    warning("Number of y_labels doesn't match effective dimensions. Using default labels.")
    y_labels <- 1:effective_length1
  }
  
  # Define theme-specific parameters
  theme_palettes <- list(
    light = list(
      bg = ggplot2::theme_light() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "white"),
          plot.background = ggplot2::element_rect(fill = "white"),
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    dark = list(
      bg = ggplot2::theme_dark() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "#222222"),
          plot.background = ggplot2::element_rect(fill = "#333333"),
          panel.grid.minor = ggplot2::element_blank(),
          plot.title = ggplot2::element_text(color = "white"),
          axis.title = ggplot2::element_text(color = "white"),
          axis.text = ggplot2::element_text(color = "white")
        )
    ),
    minimal = list(
      bg = ggplot2::theme_minimal() +
        ggplot2::theme(
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    scientific = list(
      bg = ggplot2::theme_bw() +
        ggplot2::theme(
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    bold = list(
      bg = ggplot2::theme_bw() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "white", color = "black", linewidth = 1.2),
          plot.background = ggplot2::element_rect(fill = "white"),
          panel.grid.major = ggplot2::element_line(color = "gray80", linewidth = 0.8),
          panel.grid.minor = ggplot2::element_blank(),
          plot.title = ggplot2::element_text(face = "bold", size = 14, hjust = 0.5),
          axis.title = ggplot2::element_text(face = "bold", size = 12),
          axis.text = ggplot2::element_text(face = "bold", size = 10),
          axis.line = ggplot2::element_line(linewidth = 1.2),
          axis.ticks = ggplot2::element_line(linewidth = 1.2)
        )
    ),
    void = list(
      bg = ggplot2::theme_void() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = "white", color = NA),
          plot.title = ggplot2::element_text(hjust = 0.5, margin = ggplot2::margin(b = 15)),
          plot.margin = ggplot2::margin(15, 15, 10, 15),
          legend.position = "right"  # Keep legend for symbol colors
        )
    )
  )
  
  # Select theme parameters
  if(!theme %in% names(theme_palettes)) {
    warning("Unknown theme '", theme, "'. Using 'light' theme.")
    theme <- "light"
  }
  tp <- theme_palettes[[theme]]
  
  # If no symbol colors provided, generate some
  if(is.null(symbol_colors)) {
    if(num_symbols <= 8) {
      # For few symbols, use ColorBrewer's Set1
      symbol_colors <- c("#E41A1C", "#377EB8", "#4DAF4A", "#984EA3",
                         "#FF7F00", "#FFFF33", "#A65628", "#F781BF")[1:num_symbols]
    } else {
      # For many symbols, generate a color palette
      symbol_colors <- rainbow(num_symbols)
    }
  } else if(length(symbol_colors) < num_symbols) {
    # If not enough colors provided, recycle
    symbol_colors <- rep(symbol_colors, length.out = num_symbols)
  }
  
  # Create labels for the unique symbols that appear in the data
  if(is.null(symbol_labels)) {
    symbol_labels <- character(length(unique_symbols))
    for(i in 1:length(unique_symbols)) {
      symbol_value <- unique_symbols[i]
      if(symbol_value < length(shape_names) && symbol_value >= 0) {
        symbol_labels[i] <- paste(symbol_value, ":", shape_names[symbol_value + 1])
      } else {
        symbol_labels[i] <- paste("Symbol", symbol_value)
      }
    }
  } else if(length(symbol_labels) < num_symbols) {
    # If not enough labels provided, extend
    original_labels <- symbol_labels
    symbol_labels <- character(num_symbols)
    symbol_labels[1:length(original_labels)] <- original_labels
    for(i in (length(original_labels) + 1):num_symbols) {
      symbol_labels[i] <- paste("Symbol", unique_symbols[i])
    }
  }
  
  # Create a named color vector for mapping
  names(symbol_colors) <- as.character(unique_symbols)
  
  # Create the plot with colored points by symbol
  p <- ggplot2::ggplot() +
    ggplot2::geom_point(data = plot_data,
                        ggplot2::aes(x = x, y = y, color = factor(symbol)),
                        shape = point_shape,
                        size = point_size,
                        alpha = alpha)
  
  # Apply the color scale for symbols with correct labels
  p <- p + ggplot2::scale_color_manual(
    values = symbol_colors,
    labels = symbol_labels,
    name = "Symbol"
  )
  
  # Add axis labels and title
  embedding_subtitle <- ifelse(embedding_dimension > 1,
                               paste0(" (Embedding: ", embedding_dimension,
                                      ", Delay: ", time_delay, ")"), "")
  
  p <- p + ggplot2::labs(
    title = title,
    subtitle = embedding_subtitle,
    x = x_lab,
    y = y_lab
  )
  
  # Apply theme
  p <- p + tp$bg
  
  # For void theme, we skip axis customization completely
  if(theme != "void") {
    p <- p + ggplot2::theme(
      plot.title = ggplot2::element_text(hjust = 0.5),
      panel.grid.major = if(grid) ggplot2::element_line() else ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank()
    )
    
    # Set appropriate axis ticks
    if(effective_length1 <= 50 && effective_length2 <= 50) {
      # For small matrices, show all ticks
      p <- p + ggplot2::scale_x_continuous(breaks = 1:effective_length2, labels = x_labels) +
        ggplot2::scale_y_continuous(breaks = 1:effective_length1, labels = y_labels)
    } else {
      # For larger matrices, show ~10 ticks
      x_tick_count <- min(10, effective_length2)
      y_tick_count <- min(10, effective_length1)
      x_tick_positions <- round(seq(1, effective_length2, length.out = x_tick_count))
      y_tick_positions <- round(seq(1, effective_length1, length.out = y_tick_count))
      p <- p + ggplot2::scale_x_continuous(breaks = x_tick_positions,
                                           labels = x_labels[x_tick_positions]) +
        ggplot2::scale_y_continuous(breaks = y_tick_positions,
                                    labels = y_labels[y_tick_positions])
    }
    
    # Add recurrence rate
    rr <- sum(binary_rm) / (effective_length1 * effective_length2)
    p <- p + ggplot2::labs(caption = paste("Cross-Recurrence Rate:", round(rr, 3)))
  } else {
    # For void theme, ensure there are no axes or grid lines
    # Just add the title if specified
    if(title != "") {
      p <- p + ggplot2::labs(title = title)
    }
  }
  
  return(p)
}