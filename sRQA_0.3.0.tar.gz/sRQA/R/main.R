# sRQA: An R package for symbolic recurrence quantification analysis
#' @title symbolize_ts
#' @description Convert a numeric time series into a symbolic representation
#' @param ts numeric vector containing the time series
#' @param method method for symbolization. Options include "quantiles", "ordinal", "rle", and "categorical"
#' @param num_symbols number of symbols to use
#' @param window_size size of sliding window
#' @param visualize whether to visualize symbol meanings
#' @param viz_title title for visualization
#' @param color_palette custom color palette for visualization
#' @param sensitivity parameter for shape-based methods
#' @param smooth whether to apply smoothing
#' @return Vector of symbols
#' @export
symbolize_ts <- function(ts,
                         method = "quantiles",
                         num_symbols = 4,
                         window_size = 3,
                         visualize = FALSE,
                         viz_title = NULL,
                         color_palette = NULL,
                         sensitivity = 0.5,
                         smooth = FALSE) {
  
  if(!is.numeric(ts)) {
    stop("Time series must be numeric")
  }
  
  result <- numeric(length(ts))
  n <- length(ts)
  
  # Apply smoothing if requested (reduces noise influence)
  if(smooth) {
    # Use a simple moving average for smoothing
    smooth_window <- min(3, floor(window_size/3))
    if(smooth_window > 0) {
      # Create smoothing weights
      weights <- rep(1/smooth_window, smooth_window)
      ts_smooth <- stats::filter(ts, weights, sides = 2)
      # Handle NA values at edges
      na_indices <- which(is.na(ts_smooth))
      if(length(na_indices) > 0) {
        ts_smooth[na_indices] <- ts[na_indices]
      }
      ts <- ts_smooth
    }
  }
  
  if(method == "quantiles") {
    # Divide data into equal-sized quantile groups
    breaks <- stats::quantile(ts, probs = seq(0, 1, length.out = num_symbols + 1), 
                              na.rm = TRUE, type = 2)
    # Use cut to assign symbols, then subtract 1 to make 0-indexed
    result <- as.numeric(cut(ts, breaks = breaks, include.lowest = TRUE)) - 1
  } else if(method == "ordinal_pattern") {
    # Ordinal Pattern Encoding
    if(window_size < 2) {
      stop("Window size must be at least 2 for ordinal pattern encoding")
    }
    
    # Constrain window_size to maximum of 3
    if(window_size > 3) {
      warning("For ordinal_pattern method, window_size is constrained to a maximum of 3. Setting window_size = 3.")
      window_size <- 3
    }
    
    # The number of possible patterns is the factorial of the window size
    # Each pattern corresponds to a permutation of ranks
    max_patterns <- factorial(window_size)
    
    if(num_symbols > 0 && num_symbols < max_patterns) {
      warning(paste0("num_symbols (", num_symbols, ") is smaller than the number of possible patterns (",
                     max_patterns, "). Some patterns will be grouped."))
    } else {
      num_symbols <- max_patterns
    }
    
    # Initialize result with NAs (we'll lose some values at the beginning)
    result <- rep(NA, length(ts))
    
    # For each sliding window
    for(i in 1:(length(ts) - window_size + 1)) {
      # Extract the window
      window <- ts[i:(i + window_size - 1)]
      
      # Find the rank order (permutation)
      # The rank function assigns ranks in ascending order
      # So rank(c(3,1,2)) = c(3,1,2) means the first value is the 3rd smallest, etc.
      perm <- rank(window, ties.method = "random")
      
      # For window_size = 3, use a direct mapping approach that's more intuitive
      if(window_size == 3) {
        # Map the permutation directly to a pattern ID between 0-5
        pattern_map <- c(
          "1,2,3" = 0,  # Increasing
          "1,3,2" = 1,  # Peak in middle
          "2,1,3" = 2,  # Valley in middle
          "3,1,2" = 3,  # First highest
          "3,2,1" = 4,  # Decreasing
          "2,3,1" = 5   # Last highest
        )
        
        perm_str <- paste(perm, collapse = ",")
        perm_id <- pattern_map[perm_str]
        
        # In case of unexpected pattern (shouldn't happen with window_size=3)
        if(is.na(perm_id)) {
          perm_id <- 0
        }
      } else {
        # For other window sizes, use the factorial number system
        # This is a more robust way to encode permutations
        perm_id <- 0
        for(j in 1:window_size) {
          subfactorial <- factorial(window_size - j)
          perm_id <- perm_id + (perm[j] - 1) * subfactorial
        }
      }
      
      # If we need fewer symbols than permutations, we modulo to group them
      if(num_symbols > 0 && num_symbols < max_patterns) {
        symbol <- perm_id %% num_symbols
      } else {
        symbol <- perm_id
      }
      
      # Store the symbol at the end position of the window
      result[i + window_size - 1] <- symbol
    }
    
  } else if(method == "rle") {
    # Constrain num_symbols to maximum of 8
    if(num_symbols > 8) {
      warning("For rle method, num_symbols is constrained to a maximum of 8. Setting num_symbols = 8.")
      num_symbols <- 8
    }
    
    # Initialize result with NAs
    result <- rep(NA, n)
    
    # For each sliding window
    for(i in 1:(n - window_size + 1)) {
      # Extract the window
      window <- ts[i:(i + window_size - 1)]
      
      # Calculate first differences (direction changes)
      diffs <- diff(window)
      
      # Use a percentage of the window's range as threshold
      window_range <- max(window) - min(window)
      threshold <- sensitivity * window_range / window_size
      
      # Identify direction changes, but ensure we don't have all zeros
      direction <- sign(diffs)
      if(all(abs(diffs) < threshold)) {
        # If all changes are below threshold, it's a flat line
        # Use the global trend direction
        if(window[window_size] > window[1]) {
          direction <- rep(1, length(diffs))  # Upward trend
        } else if(window[window_size] < window[1]) {
          direction <- rep(-1, length(diffs))  # Downward trend
        } else {
          direction <- rep(0, length(diffs))   # Truly flat
        }
      } else {
        # Only treat small changes as flat
        direction[abs(diffs) < threshold] <- 0
      }
      
      # Count direction changes using runs
      runs <- rle(direction)
      num_runs <- length(runs$lengths)
      
      # Determine shape based on the pattern
      shape <- NULL
      
      if(num_runs == 1) {
        # Single direction throughout window
        if(runs$values[1] > 0) {
          shape <- 0  # Increasing
        } else if(runs$values[1] < 0) {
          shape <- 1  # Decreasing
        } else {
          shape <- 0  # Flat (default to increasing)
        }
      } else if(num_runs == 2) {
        # Two directions - check for peaks, valleys, steps
        if(runs$values[1] > 0 && runs$values[2] < 0) {
          shape <- 2  # Peak
        } else if(runs$values[1] < 0 && runs$values[2] > 0) {
          shape <- 3  # Valley
        } else if(runs$values[1] > 0 && runs$values[2] == 0) {
          shape <- 4  # Step up
        } else if(runs$values[1] < 0 && runs$values[2] == 0) {
          shape <- 5  # Step down
        } else if(runs$values[1] == 0 && runs$values[2] > 0) {
          shape <- 0  # Flat then increase
        } else if(runs$values[1] == 0 && runs$values[2] < 0) {
          shape <- 1  # Flat then decrease
        } else {
          # Other cases (should be rare)
          shape <- 2  # Default to peak
        }
      } else if(num_runs == 3) {
        # Three segments - oscillations or more complex patterns
        if(runs$values[1] > 0 && runs$values[2] < 0 && runs$values[3] > 0) {
          shape <- 6  # Up-down-up
        } else if(runs$values[1] < 0 && runs$values[2] > 0 && runs$values[3] < 0) {
          shape <- 7  # Down-up-down
        } else {
          # Handle other 3-segment patterns
          # Count dominant direction
          upward_count <- sum(runs$lengths[runs$values > 0])
          downward_count <- sum(runs$lengths[runs$values < 0])
          
          if(upward_count > downward_count) {
            shape <- 6  # More upward movement
          } else {
            shape <- 7  # More downward movement
          }
        }
      } else if(num_runs > 3) {
        # More complex patterns with many direction changes
        # Look for alternating pattern
        is_alternating <- TRUE
        sign_changes <- 0
        
        for(j in 2:length(runs$values)) {
          if(runs$values[j] != 0 && runs$values[j-1] != 0) {
            if(sign(runs$values[j]) == sign(runs$values[j-1])) {
              is_alternating <- FALSE
              break
            } else {
              sign_changes <- sign_changes + 1
            }
          }
        }
        
        if(is_alternating && sign_changes >= 2) {
          # True oscillation pattern
          if(runs$values[1] > 0) {
            shape <- 6  # Starting upward
          } else {
            shape <- 7  # Starting downward
          }
        } else {
          # Mixed pattern - determine dominant direction
          upward_count <- sum(runs$lengths[runs$values > 0])
          downward_count <- sum(runs$lengths[runs$values < 0])
          
          if(upward_count > downward_count) {
            shape <- 6  # More upward
          } else {
            shape <- 7  # More downward
          }
        }
      }
      
      # Ensure shape is within num_symbols range
      if(!is.null(shape) && shape >= num_symbols) {
        shape <- shape %% num_symbols
      }
      
      # Assign pattern to the CENTER point of this window only
      center_idx <- i + floor(window_size / 2)
      result[center_idx] <- shape
    }
    
  } else if(method == "categorical" && is.factor(ts)) {
    # Handle categorical/nominal data case (for data that's already symbolic)
    # For categorical data that's already in factor form
    # Just convert to numeric representation
    result <- as.numeric(ts) - 1  # Subtract 1 to make 0-based
  } else {
    stop("Unknown method: ", method)
  }
  
  # Attach method and num_symbols as attributes for label support
  attr(result, "method") <- method
  attr(result, "num_symbols") <- num_symbols
  
  # Optionally visualize the symbols
  if(visualize) {
    # Call visualize_symbols function, passing method for proper labels
    plot_obj <- visualize_symbols(ts = ts, symbols = result, method = method,
                                  title = viz_title, symbol_colors = color_palette)
    print(plot_obj)
  }
  
  # Return the symbolized time series
  return(result)
}

#' @title Get symbol labels
#' @description Get appropriate labels for symbols based on the symbolization method
#' @param method symbolization method used
#' @param num_symbols number of symbols
#' @return character vector of labels
#' @export
get_symbol_labels <- function(method, num_symbols) {
  
  if(is.null(method)) {
    # Generic labels if no method provided
    return(paste("Symbol", 0:(num_symbols-1)))
  }
  
  if(method == "rle") {
    # Shape primitive labels (max 8)
    shape_labels <- c(
      "Increasing",        # 0
      "Decreasing",        # 1
      "Peak",              # 2
      "Valley",            # 3
      "Step up",           # 4
      "Step down",         # 5
      "Oscillation up",    # 6
      "Oscillation down"   # 7
    )
    
    # Return only the number of labels needed
    if(num_symbols <= length(shape_labels)) {
      return(shape_labels[1:num_symbols])
    } else {
      # If somehow more symbols requested, extend with generic labels
      return(c(shape_labels, paste("Symbol", length(shape_labels):(num_symbols-1))))
    }
    
  } else if(method == "ordinal_pattern") {
    # Ordinal pattern labels (max 6 for window_size=3)
    ordinal_labels <- c(
      "Increasing",        # 0: [1,2,3]
      "Peak",              # 1: [1,3,2]
      "Valley",            # 2: [2,1,3]
      "Decreasing early",  # 3: [3,1,2]
      "Decreasing",        # 4: [3,2,1]
      "Increasing late"    # 5: [2,3,1]
    )
    
    # Return only the number of labels needed
    if(num_symbols <= length(ordinal_labels)) {
      return(ordinal_labels[1:num_symbols])
    } else {
      # If somehow more symbols requested, extend with generic labels
      return(c(ordinal_labels, paste("Symbol", length(ordinal_labels):(num_symbols-1))))
    }
    
  } else if(method == "quantiles") {
    # Quantile labels
    return(paste0("Q", 1:num_symbols))
    
  } else if(method == "categorical") {
    # Generic labels for categorical
    return(paste("Category", 0:(num_symbols-1)))
    
  } else {
    # Default to generic labels for unknown methods
    return(paste("Symbol", 0:(num_symbols-1)))
  }
}

#' @title Symbolic recurrence matrix
#' @description Create a recurrence matrix based on symbolic time series
#' @param symbols vector of symbols (integers or characters)
#' @param embedding_dimension embedding dimension
#' @param time_delay time delay for embedding
#' @param window_size size of the sliding window (should be >= embedding_dimension)
#' @param recurrence_criterion function to determine recurrence (default: exact match)
#' @param distance_method when recurrence_criterion is not provided, the method to calculate distance ("hamming")
#' @param threshold threshold for distance-based recurrence
#' @return recurrence matrix (logical matrix)
#' @export
symbolic_recurrence_matrix <- function(symbols, embedding_dimension = 1, time_delay = 1,
                                       window_size = embedding_dimension,
                                       recurrence_criterion = NULL,
                                       distance_method = "hamming",
                                       threshold = 0) {
  n <- length(symbols)
  if(window_size < embedding_dimension) {
    warning("Window size should be >= embedding dimension. Setting window_size = embedding_dimension.")
    window_size <- embedding_dimension
  }
  
  # Determine the effective length after embedding
  effective_length <- n - (embedding_dimension - 1) * time_delay - (window_size - 1)
  
  if(effective_length <= 0) {
    stop("Time series too short for the chosen embedding parameters")
  }
  
  # Create state vectors
  state_vectors <- list()
  for(i in 1:effective_length) {
    # Extract window starting at position i
    indices <- i + (0:(window_size-1))
    # Ensure indices are within bounds
    indices <- indices[indices <= n]
    window <- symbols[indices]
    
    # Create state vector
    if(embedding_dimension == 1) {
      state_vectors[[i]] <- window
    } else {
      # Use delay embedding
      embedded_indices <- seq(1, length(window), by = time_delay)
      if(length(embedded_indices) >= embedding_dimension) {
        embedded_indices <- embedded_indices[1:embedding_dimension]
        state_vectors[[i]] <- window[embedded_indices]
      } else {
        stop("Window size too small for the chosen embedding dimension and time delay")
      }
    }
  }
  
  # Prepare recurrence criterion if not provided
  if(is.null(recurrence_criterion)) {
    # Create appropriate distance function based on method
    if(distance_method == "hamming") {
      # Hamming distance: count of positions where symbols differ
      distance_fun <- function(x, y) {
        if(length(x) != length(y)) return(max(length(x), length(y)))
        sum(x != y)
      }
    } else {
      stop("Unsupported distance method: ", distance_method)
    }
    
    # Create recurrence criterion using the distance function
    recurrence_criterion <- function(x, y) {
      distance_fun(x, y) <= threshold
    }
  }
  
  # Calculate recurrence matrix
  rm <- matrix(FALSE, nrow = effective_length, ncol = effective_length)
  
  for(i in 1:effective_length) {
    for(j in 1:effective_length) {
      # Handle NA values in state vectors
      if(any(is.na(state_vectors[[i]])) || any(is.na(state_vectors[[j]]))) {
        rm[i, j] <- FALSE  # Non-recurrence if either vector has NA
      } else {
        # Only apply recurrence criterion if neither vector has NA
        rm[i, j] <- recurrence_criterion(state_vectors[[i]], state_vectors[[j]])
      }
    }
  }
  
  return(rm)
}

#' @title RQA measures
#' @description Calculate recurrence quantification analysis measures
#' @param rm recurrence matrix (logical matrix)
#' @param min_line_length minimum length for diagonal and vertical lines
#' @param border number of diagonals to exclude near matrix borders for TREND calculation (default: 10)
#' @return list of RQA measures
#' @export
quant_rqa <- function(rm, min_line_length = 2, border = 10) {
  
  n <- nrow(rm)
  
  # Recurrence Rate (RR) - excluding main diagonal
  RR <- (sum(rm) - n) / (n * n - n)
  
  # Calculate diagonal line lengths (EXCLUDING main diagonal)
  diagonal_lengths <- c()
  for(i in -(n-1):(n-1)) {
    # Skip the main diagonal (i == 0)
    if(i == 0) next
    
    # Extract the diagonal manually since diag() works differently for offset diagonals
    if (i < 0) {
      row_indices <- 1:(n+i)
      col_indices <- (1-i):n
    } else {
      row_indices <- (1+i):n
      col_indices <- 1:(n-i)
    }
    diag_i <- rm[cbind(row_indices, col_indices)]
    
    # Find consecutive TRUEs
    runs <- rle(diag_i)
    diagonal_lengths <- c(diagonal_lengths, runs$lengths[runs$values])
  }
  
  # Calculate vertical line lengths
  vertical_lengths <- c()
  for(j in 1:n) {
    col_j <- rm[, j]
    runs <- rle(col_j)
    vertical_lengths <- c(vertical_lengths, runs$lengths[runs$values])
  }
  
  # Calculate recurrence times
  # Recurrence times are the vertical distances between consecutive recurrent structures
  recurrence_times <- c()
  
  for(j in 1:n) {
    col_j <- rm[, j]
    
    # Find the positions of recurrent points
    recurrent_positions <- which(col_j)
    
    if(length(recurrent_positions) > 0) {
      # Get runs of recurrent points to identify structures
      runs <- rle(col_j)
      
      # Find the midpoints of each recurrent structure
      midpoints <- c()
      current_pos <- 1
      
      for(k in 1:length(runs$lengths)) {
        if(runs$values[k]) {
          # This is a recurrent structure
          start_pos <- current_pos
          end_pos <- current_pos + runs$lengths[k] - 1
          midpoint <- floor((start_pos + end_pos) / 2)
          midpoints <- c(midpoints, midpoint)
        }
        current_pos <- current_pos + runs$lengths[k]
      }
      
      # Calculate distances between consecutive midpoints
      if(length(midpoints) > 1) {
        recurrence_times <- c(recurrence_times, diff(midpoints))
      }
    }
  }
  
  # Filter by minimum line length
  diagonal_lengths <- diagonal_lengths[diagonal_lengths >= min_line_length]
  vertical_lengths <- vertical_lengths[vertical_lengths >= min_line_length]
  recurrence_times <- recurrence_times[recurrence_times >= min_line_length]
  
  # Determinism (DET) - proportion of recurrence points forming diagonal lines
  # Denominator should exclude main diagonal
  if(length(diagonal_lengths) > 0) {
    DET <- sum(diagonal_lengths) / (sum(rm) - n)
  } else {
    DET <- 0
  }
  
  # Average diagonal line length (L)
  if(length(diagonal_lengths) > 0) {
    L <- mean(diagonal_lengths)
  } else {
    L <- 0
  }
  
  # Longest diagonal line (Lmax)
  if(length(diagonal_lengths) > 0) {
    Lmax <- max(diagonal_lengths)
  } else {
    Lmax <- 0
  }
  
  # Divergence (DIV) - inverse of Lmax
  if(Lmax > 0) {
    DIV <- 1 / Lmax
  } else {
    DIV <- Inf
  }
  
  # Laminarity (LAM) - proportion of recurrence points forming vertical lines
  if(length(vertical_lengths) > 0) {
    LAM <- sum(vertical_lengths) / sum(rm)
  } else {
    LAM <- 0
  }
  
  # Trapping time (TT) - average vertical line length
  if(length(vertical_lengths) > 0) {
    TT <- mean(vertical_lengths)
  } else {
    TT <- 0
  }
  
  # Maximum vertical line length (Vmax)
  if(length(vertical_lengths) > 0) {
    Vmax <- max(vertical_lengths)
  } else {
    Vmax <- 0
  }
  
  # Entropy of diagonal line lengths (ENTR)
  if(length(diagonal_lengths) > 0) {
    # Calculate histogram
    hist_diag <- table(diagonal_lengths)
    prob_diag <- hist_diag / sum(hist_diag)
    ENTR <- -sum(prob_diag * log(prob_diag))
  } else {
    ENTR <- NaN
  }
  
  # Entropy of vertical line lengths (VENTR)
  if(length(vertical_lengths) > 0) {
    # Calculate histogram
    hist_vert <- table(vertical_lengths)
    prob_vert <- hist_vert / sum(hist_vert)
    VENTR <- -sum(prob_vert * log(prob_vert))
  } else {
    VENTR <- NaN
  }
  
  # Mean Recurrence Time (MRT)
  if(length(recurrence_times) > 0) {
    MRT <- mean(recurrence_times)
  } else {
    MRT <- 0
  }
  
  # Recurrence Time Entropy (RTE)
  if(length(recurrence_times) > 0) {
    # Calculate histogram
    hist_rt <- table(recurrence_times)
    prob_rt <- hist_rt / sum(hist_rt)
    RTE <- -sum(prob_rt * log(prob_rt))
  } else {
    RTE <- NaN
  }
  
  # Number of Most Probable Recurrence Time (NMPRT)
  if(length(recurrence_times) > 0) {
    # Find the most frequently occurring recurrence time
    hist_rt <- table(recurrence_times)
    NMPRT <- max(hist_rt)
  } else {
    NMPRT <- 0
  }
  
  # TREND - trend of recurrences
  # This measures the slope of recurrence rate vs. distance from LOI
  tau <- 1  # Theiler window (excluding LOI)
  N_tilde <- n - border
  
  if(N_tilde <= tau) {
    # Not enough diagonals to calculate trend
    TREND <- NA
  } else {
    # Calculate local recurrence rate for each diagonal
    RR_d <- numeric(N_tilde - tau)
    delta_d <- numeric(N_tilde - tau)
    
    for(d in (tau + 1):N_tilde) {
      # Extract diagonal d (above the LOI)
      row_indices <- 1:(n - d + 1)
      col_indices <- d:n
      
      # Get the diagonal
      diag_d <- rm[cbind(row_indices, col_indices)]
      
      # Local recurrence rate for this diagonal
      RR_d[d - tau] <- sum(diag_d) / length(diag_d)
      
      # Balanced distance measure
      delta_d[d - tau] <- d - (N_tilde + tau) / 2
    }
    
    # Calculate mean RR
    mean_RR <- mean(RR_d)
    
    # Calculate TREND using the formula
    numerator <- sum(delta_d * (RR_d - mean_RR))
    denominator <- sum(delta_d^2)
    
    if(denominator == 0) {
      TREND <- 0
    } else {
      # Factor of 1000 to express as change per 1000 data points
      TREND <- 1000 * numerator / denominator
    }
  }
  
  return(list(
    RR = RR,           # Recurrence Rate
    DET = DET,         # Determinism
    L = L,             # Average diagonal line length
    Lmax = Lmax,       # Longest diagonal line
    DIV = DIV,         # Divergence (inverse of Lmax)
    ENTR = ENTR,       # Entropy of diagonal line distribution
    LAM = LAM,         # Laminarity
    TT = TT,           # Trapping time (average vertical line)
    Vmax = Vmax,       # Maximum vertical line length
    VENTR = VENTR,     # Entropy of vertical line distribution
    MRT = MRT,         # Mean recurrence time
    RTE = RTE,         # Recurrence time entropy
    NMPRT = NMPRT,     # Number of most probable recurrence time
    TREND = TREND      # Trend of recurrences
  ))
}


#' @title Plot recurrence plot
#' @description Create a visualization of the recurrence matrix
#' @param rm recurrence matrix
#' @param main plot title
#' @param col color for recurrence points (default: black)
#' @param enhanced logical, whether to use enhanced visualization with grid lines and scales
#' @param highlight_diag logical, whether to highlight the main diagonal
#' @param diag_col color for the main diagonal
#' @param point_size size of points when using enhanced visualization (only applies if enhanced=TRUE)
#' @param grid_col color for grid lines (only applies if enhanced=TRUE)
#' @param colormap optional color gradient function (for continuous distance matrices)
#' @param labels time labels to use for axes (NULL for default integer indices)
#' @export
plot_recurrence <- function(rm, main = "Symbolic Recurrence Plot", col = "black",
                            enhanced = FALSE, highlight_diag = TRUE, diag_col = "red",
                            point_size = 0.5, grid_col = "gray90",
                            colormap = NULL, labels = NULL) {
  n <- nrow(rm)
  
  # Check if the matrix is logical (binary) or numeric (distance)
  is_binary <- is.logical(rm) || (is.numeric(rm) && all(rm %in% c(0, 1)))
  
  # Set up labels if provided
  if(is.null(labels)) {
    x_labels <- 1:n
    y_labels <- 1:n
  } else {
    if(length(labels) != n) {
      warning("Number of labels does not match recurrence matrix dimensions")
      x_labels <- 1:n
      y_labels <- 1:n
    } else {
      x_labels <- labels
      y_labels <- labels
    }
  }
  
  if(!enhanced) {
    # Basic visualization using image()
    if(is_binary) {
      # Binary recurrence plot
      image(1:n, 1:n, rm,
            col = c("white", col),
            xlab = "Time index",
            ylab = "Time index",
            main = main,
            axes = FALSE)
      
      # Add axes with proper labels
      axis(1, at = seq(1, n, length.out = min(10, n)), labels = x_labels[seq(1, n, length.out = min(10, n))])
      axis(2, at = seq(1, n, length.out = min(10, n)), labels = y_labels[seq(1, n, length.out = min(10, n))])
      box()
      
      # Add main diagonal if requested
      if(highlight_diag) {
        points(1:n, 1:n, type = "l", col = diag_col, lwd = 2)
      }
    } else {
      # Continuous recurrence plot (distances)
      if(is.null(colormap)) {
        # Default colormap from white to dark blue
        colormap <- grDevices::colorRampPalette(c("white", "lightblue", "blue", "darkblue"))(100)
      }
      
      image(1:n, 1:n, rm,
            col = colormap,
            xlab = "Time index",
            ylab = "Time index",
            main = main,
            axes = FALSE)
      
      # Add axes with proper labels
      axis(1, at = seq(1, n, length.out = min(10, n)), labels = x_labels[seq(1, n, length.out = min(10, n))])
      axis(2, at = seq(1, n, length.out = min(10, n)), labels = y_labels[seq(1, n, length.out = min(10, n))])
      box()
      
      # Add a color legend
      graphics::image.plot(1:n, 1:n, rm,
                           col = colormap,
                           xlab = "Time index",
                           ylab = "Time index",
                           main = main,
                           axes = FALSE)
    }
  } else {
    # Enhanced visualization using base plot
    # Set up the plot area
    plot(NA, NA, xlim = c(1, n), ylim = c(1, n),
         xlab = "Time index", ylab = "Time index",
         main = main, axes = FALSE)
    
    # Add grid lines
    grid_points <- seq(1, n, by = max(1, floor(n/20)))
    abline(h = grid_points, col = grid_col, lty = 3)
    abline(v = grid_points, col = grid_col, lty = 3)
    
    # Add axes with proper labels
    axis(1, at = seq(1, n, length.out = min(10, n)), labels = x_labels[seq(1, n, length.out = min(10, n))])
    axis(2, at = seq(1, n, length.out = min(10, n)), labels = y_labels[seq(1, n, length.out = min(10, n))])
    box()
    
    if(is_binary) {
      # Plot recurrence points
      recurrence_indices <- which(rm, arr.ind = TRUE)
      if(nrow(recurrence_indices) > 0) {
        points(recurrence_indices[, 2], recurrence_indices[, 1],
               pch = 15, col = col, cex = point_size)
      }
      
      # Add main diagonal if requested
      if(highlight_diag) {
        points(1:n, 1:n, type = "l", col = diag_col, lwd = 2)
      }
    } else {
      # For continuous recurrence plots, convert to colors
      if(is.null(colormap)) {
        # Default colormap from white to dark blue
        colormap <- grDevices::colorRampPalette(c("white", "lightblue", "blue", "darkblue"))(100)
      }
      
      # Normalize values to [0,1] for color mapping
      rm_normalized <- (rm - min(rm, na.rm = TRUE)) /
        (max(rm, na.rm = TRUE) - min(rm, na.rm = TRUE))
      
      # Convert to color indices
      color_indices <- floor(rm_normalized * (length(colormap) - 1)) + 1
      
      # Plot points with appropriate colors
      for(i in 1:n) {
        for(j in 1:n) {
          if(!is.na(rm[i, j]) && rm[i, j] > 0) {
            points(j, i, pch = 15,
                   col = colormap[color_indices[i, j]],
                   cex = point_size)
          }
        }
      }
      
      # Add a color legend
      # This is a simple legend - for production code, consider using a proper legend function
      legend_breaks <- seq(min(rm, na.rm = TRUE), max(rm, na.rm = TRUE), length.out = 5)
      legend_colors <- colormap[seq(1, length(colormap), length.out = length(legend_breaks))]
      legend("topright", legend = round(legend_breaks, 2),
             fill = legend_colors, title = "Distance", cex = 0.8)
    }
  }
}


#' @title Visualize symbolic patterns
#' @description Create a ggplot visualization of the symbolic patterns in a time series
#' @param ts original time series
#' @param symbols vector of symbols from symbolize_ts
#' @param method symbolization method (optional, will try to get from symbol attributes)
#' @param title custom plot title
#' @param symbol_colors custom color palette for symbols
#' @param point_size size of points
#' @param line_size width of line segments
#' @param alpha transparency of points and lines
#' @return ggplot object
#' @export
visualize_symbols <- function(ts, symbols, method = NULL, title = NULL, 
                              symbol_colors = NULL, point_size = 2.5, 
                              line_size = 0.8, alpha = 0.8) {
  
  # Ensure required packages are available
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Package 'ggplot2' is needed for this function to work. Please install it.")
  }
  
  # Check inputs
  if(length(ts) != length(symbols)) {
    stop("Length of time series does not match length of symbols")
  }
  
  # Handle NA values in symbols
  if(any(is.na(symbols))) {
    warning("NA values detected in symbols. These will be displayed but not colored.")
  }
  
  # Try to get method from attributes if not provided
  if(is.null(method)) {
    method <- attr(symbols, "method")
  }
  
  # Get unique symbols (excluding NA)
  unique_symbols <- sort(unique(symbols[!is.na(symbols)]))
  num_symbols <- length(unique_symbols)
  
  # Get appropriate labels based on method
  if(!is.null(method)) {
    # Try to get num_symbols from attributes if available
    attr_num_symbols <- attr(symbols, "num_symbols")
    if(!is.null(attr_num_symbols)) {
      all_labels <- get_symbol_labels(method, attr_num_symbols)
    } else {
      all_labels <- get_symbol_labels(method, num_symbols)
    }
    # Only use the labels for symbols that actually appear
    # Symbols are 0-indexed, so add 1 to get label position
    symbol_labels <- all_labels[unique_symbols + 1]
  } else {
    # Generic labels if no method available
    symbol_labels <- paste("Symbol", unique_symbols)
  }
  
  # Create default color palette if not provided
  if(is.null(symbol_colors)) {
    # Use a warm, saturated color palette (avoiding pastel rainbow)
    symbol_colors <- rainbow(num_symbols, s = 0.8, v = 0.9, start = 0, end = 0.85)
  } else if(length(symbol_colors) < num_symbols) {
    # If not enough colors provided, recycle
    symbol_colors <- rep(symbol_colors, length.out = num_symbols)
  }
  
  # Create default title if not provided
  if(is.null(title)) {
    if(!is.null(method)) {
      title <- paste("Symbolized Time Series (", method, ")", sep = "")
    } else {
      title <- "Symbolized Time Series"
    }
  }
  
  # Create data frame
  df <- data.frame(
    time = seq_along(ts),
    value = ts,
    symbol = factor(symbols, levels = unique_symbols, labels = symbol_labels)
  )
  
  # Filter out rows with NA symbols to prevent them from appearing in legend
  df_valid <- df[!is.na(df$symbol), ]
  
  # Create segment data frame (each row is a line segment)
  # Each segment connects consecutive points and is colored by the ENDING point's symbol
  # This is more intuitive for ordinal patterns which are assigned to the end of windows
  df_segments <- data.frame(
    x = df$time[-nrow(df)],
    y = df$value[-nrow(df)],
    xend = df$time[-1],
    yend = df$value[-1],
    symbol = df$symbol[-1]  # Use ending point's symbol instead of starting point
  )
  # Remove segments with NA symbols
  df_segments <- df_segments[!is.na(df_segments$symbol), ]
  
  # Create plot - use df_valid for points to exclude NAs from legend
  p <- ggplot2::ggplot() +
    ggplot2::geom_segment(data = df_segments, 
                          ggplot2::aes(x = x, y = y, xend = xend, yend = yend, color = symbol),
                          linewidth = line_size, alpha = alpha) +
    ggplot2::geom_point(data = df_valid, ggplot2::aes(x = time, y = value, color = symbol), 
                        size = point_size, alpha = 0.9) +
    ggplot2::scale_color_manual(values = symbol_colors, name = "Symbol Type") +
    ggplot2::labs(
      title = title,
      x = "Time",
      y = "Value"
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.title = ggplot2::element_text(hjust = 0.5, size = 14, face = "bold"),
      legend.position = "right"
    )
  
  return(p)
}


#' @title Create ggplot-based recurrence plot
#' @description Create a recurrence plot visualization using ggplot2
#' @param rm recurrence matrix
#' @param title plot title
#' @param theme plot theme (light, dark, minimal, scientific, bold, void)
#' @param highlight_diagonal whether to highlight the main diagonal
#' @param diagonal_color color for the main diagonal
#' @param grid whether to show grid lines
#' @param point_size size of recurrence points
#' @param point_shape shape of recurrence points
#' @param alpha transparency of points/tiles
#' @param use_viridis which viridis colormap to use for continuous matrices
#' @param axis_labels custom labels for axes
#' @param time_unit unit for time axes
#' @param point_color custom color for recurrence points
#' @return ggplot object
#' @export
ggplot_recurrence <- function(rm,
                              title = "Recurrence Plot",
                              theme = "light",
                              highlight_diagonal = TRUE,
                              diagonal_color = NULL,
                              grid = TRUE,
                              point_size = 1,
                              point_shape = 15,
                              alpha = 1,
                              use_viridis = NULL,
                              axis_labels = NULL,
                              time_unit = "index",
                              point_color = NULL) {
  
  # Ensure required packages are available
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Package 'ggplot2' is needed for this function to work. Please install it.")
  }
  
  if (!requireNamespace("reshape2", quietly = TRUE)) {
    stop("Package 'reshape2' is needed for this function to work. Please install it.")
  }
  
  # Handle NA values
  if(any(is.na(rm))) {
    warning("NA values detected in recurrence matrix. Replacing with FALSE/0.")
    if(is.logical(rm)) {
      rm[is.na(rm)] <- FALSE
    } else {
      rm[is.na(rm)] <- 0
    }
  }
  
  n <- nrow(rm)
  is_binary <- is.logical(rm) || (is.numeric(rm) && all(rm %in% c(0, 1)))
  
  # Create axis labels if not provided
  if(is.null(axis_labels)) {
    axis_labels <- 1:n
  } else if(length(axis_labels) != n) {
    warning("Number of labels doesn't match matrix dimensions. Using default labels.")
    axis_labels <- 1:n
  }
  
  # Define theme-specific parameters
  theme_palettes <- list(
    light = list(
      binary_color = "#3498db",
      diagonal = "#e74c3c",
      bg = ggplot2::theme_light() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "white"),
          plot.background = ggplot2::element_rect(fill = "white"),
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    dark = list(
      binary_color = "#3498db",
      diagonal = "#e74c3c",
      bg = ggplot2::theme_dark() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "#222222"),
          plot.background = ggplot2::element_rect(fill = "#333333"),
          panel.grid.minor = ggplot2::element_blank(),
          plot.title = ggplot2::element_text(color = "white"),
          axis.title = ggplot2::element_text(color = "white"),
          axis.text = ggplot2::element_text(color = "white")
        )
    ),
    minimal = list(
      binary_color = "#3498db",
      diagonal = "#e74c3c",
      bg = ggplot2::theme_minimal() +
        ggplot2::theme(
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    scientific = list(
      binary_color = "black",
      diagonal = "red",
      bg = ggplot2::theme_bw() +
        ggplot2::theme(
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    bold = list(
      binary_color = "#1E88E5", # Vibrant blue
      diagonal = "#D81B60",     # Bold magenta/pink
      bg = ggplot2::theme_bw() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "white", color = "black", linewidth = 1.2),
          plot.background = ggplot2::element_rect(fill = "white"),
          panel.grid.major = ggplot2::element_line(color = "gray80", linewidth = 0.8),
          panel.grid.minor = ggplot2::element_blank(),
          plot.title = ggplot2::element_text(face = "bold", size = 14, hjust = 0.5),
          axis.title = ggplot2::element_text(face = "bold", size = 12),
          axis.text = ggplot2::element_text(face = "bold", size = 10),
          axis.line = ggplot2::element_line(linewidth = 1.2),
          axis.ticks = ggplot2::element_line(linewidth = 1.2)
        )
    ),
    void = list(
      binary_color = "#3498db",
      diagonal = "#e74c3c",
      bg = ggplot2::theme_void() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = "white", color = NA),
          plot.title = ggplot2::element_text(hjust = 0.5, margin = ggplot2::margin(b = 15)),
          plot.margin = ggplot2::margin(15, 15, 10, 15),
          legend.position = "none"
        )
    )
  )
  
  # Select theme parameters
  if(!theme %in% names(theme_palettes)) {
    warning("Unknown theme '", theme, "'. Using 'light' theme.")
    theme <- "light"
  }
  tp <- theme_palettes[[theme]]
  
  # Override diagonal color if specified
  if(!is.null(diagonal_color)) {
    tp$diagonal <- diagonal_color
  }
  
  # Override binary color if point_color is specified
  if(!is.null(point_color)) {
    tp$binary_color <- point_color
  }
  
  # Create the diagonal data separately to avoid aesthetic mapping issues
  diag_df <- data.frame(x = 1:n, y = 1:n)
  
  # Create the plot
  if(is_binary) {
    # For binary matrices, extract only TRUE/1 positions for efficiency
    plot_data <- which(rm == TRUE, arr.ind = TRUE)
    colnames(plot_data) <- c("y", "x")  # Swap for correct orientation
    plot_data <- as.data.frame(plot_data)
    
    # Create plot with points
    p <- ggplot2::ggplot() +
      ggplot2::geom_point(data = plot_data,
                          ggplot2::aes(x = x, y = y),
                          color = tp$binary_color,
                          shape = point_shape,
                          size = point_size,
                          alpha = alpha)
  } else {
    # For continuous matrices, convert to long format
    plot_data <- reshape2::melt(rm)
    colnames(plot_data) <- c("y", "x", "value")
    
    # Create plot with tiles
    p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = x, y = y, fill = value)) +
      ggplot2::geom_tile(alpha = alpha)
    
    # Apply color palette based on point_color parameter, theme and viridis option
    if(!is.null(point_color)) {
      # Custom color for continuous matrices
      p <- p + ggplot2::scale_fill_gradient(low = "white", high = point_color)
    } else if(!is.null(use_viridis)) {
      p <- p + ggplot2::scale_fill_viridis_c(option = use_viridis)
    } else {
      # Default color scales by theme
      if(theme == "light") {
        p <- p + ggplot2::scale_fill_gradient(low = "white", high = "#3498db")
      } else if(theme == "dark") {
        p <- p + ggplot2::scale_fill_viridis_c(option = "viridis")
      } else if(theme == "minimal") {
        p <- p + ggplot2::scale_fill_gradient(low = "white", high = "#3498db")
      } else if(theme == "scientific") {
        p <- p + ggplot2::scale_fill_gradient(low = "white", high = "black")
      } else if(theme == "bold") {
        p <- p + ggplot2::scale_fill_gradient(low = "white", high = "#1E88E5",
                                              guide = ggplot2::guide_colorbar(
                                                frame.colour = "black",
                                                frame.linewidth = 1.2,
                                                ticks.colour = "black",
                                                ticks.linewidth = 1.2
                                              ))
      } else if(theme == "void") {
        p <- p + ggplot2::scale_fill_gradient(low = "white", high = "#3498db", guide = "none")
      }
    }
  }
  
  # Add diagonal line if requested - as a separate layer to avoid aesthetic mapping issues
  if(highlight_diagonal) {
    p <- p + ggplot2::geom_line(data = diag_df,
                                ggplot2::aes(x = x, y = y),
                                color = tp$diagonal,
                                size = 0.8,
                                alpha = 0.8)
  }
  
  # Add axis labels and title
  p <- p + ggplot2::labs(
    title = title,
    x = paste0("Time (", time_unit, ")"),
    y = paste0("Time (", time_unit, ")")
  )
  
  # Apply theme and customize axes
  p <- p + tp$bg
  
  # For void theme, we skip axis customization completely
  if(theme != "void") {
    p <- p + ggplot2::theme(
      plot.title = ggplot2::element_text(hjust = 0.5),
      panel.grid.major = if(grid) ggplot2::element_line() else ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      legend.position = if(is_binary) "none" else "right"
    )
    
    # Set appropriate axis ticks
    if(n <= 50) {
      # For small matrices, show all ticks
      p <- p + ggplot2::scale_x_continuous(breaks = 1:n, labels = axis_labels) +
        ggplot2::scale_y_continuous(breaks = 1:n, labels = axis_labels)
    } else {
      # For larger matrices, show ~10 ticks
      tick_count <- min(10, n)
      tick_positions <- round(seq(1, n, length.out = tick_count))
      p <- p + ggplot2::scale_x_continuous(breaks = tick_positions,
                                           labels = axis_labels[tick_positions]) +
        ggplot2::scale_y_continuous(breaks = tick_positions,
                                    labels = axis_labels[tick_positions])
    }
    
    # Add recurrence rate as a caption
    rr <- sum(rm) / (n * n)
    p <- p + ggplot2::labs(caption = paste("Recurrence Rate:", round(rr, 3)))
  } else {
    # For void theme, ensure there are no axes or grid lines
    # Just add the title if specified
    if(title != "") {
      p <- p + ggplot2::labs(title = title)
    }
  }
  
  return(p)
}

#' @title Symbol color-coded recurrence plot
#' @description Create a recurrence plot with colors based on symbol types
#' @param symbols vector of symbols
#' @param method symbolization method (optional, will try to get from symbol attributes)
#' @param embedding_dimension embedding dimension
#' @param time_delay time delay for embedding
#' @param window_size size of sliding window
#' @param title plot title
#' @param theme plot theme
#' @param highlight_diagonal whether to highlight the main diagonal
#' @param diagonal_color color for the main diagonal
#' @param grid whether to show grid lines
#' @param point_size size of recurrence points
#' @param point_shape shape of recurrence points
#' @param alpha transparency of points
#' @param symbol_colors custom colors for symbols
#' @param symbol_labels custom labels for symbols (optional, will use method-specific labels if not provided)
#' @param axis_labels custom labels for axes
#' @param time_unit unit for time axes
#' @return ggplot object
#' @export
symbol_recurrence_plot <- function(symbols,
                                   method = NULL,
                                   embedding_dimension = 1,
                                   time_delay = 1,
                                   window_size = embedding_dimension,
                                   title = "Symbol Color-Coded Recurrence Plot",
                                   theme = "light",
                                   highlight_diagonal = TRUE,
                                   diagonal_color = NULL,
                                   grid = TRUE,
                                   point_size = 1,
                                   point_shape = 15,
                                   alpha = 1,
                                   symbol_colors = NULL,
                                   symbol_labels = NULL,
                                   axis_labels = NULL,
                                   time_unit = "index") {
  
  # Ensure required packages are available
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Package 'ggplot2' is needed for this function to work. Please install it.")
  }
  
  if (!requireNamespace("reshape2", quietly = TRUE)) {
    stop("Package 'reshape2' is needed for this function to work. Please install it.")
  }
  
  # Handle empty or invalid input
  if(is.null(symbols) || length(symbols) == 0) {
    stop("Symbol vector cannot be empty")
  }
  
  # Try to get method from attributes if not provided
  if(is.null(method)) {
    method <- attr(symbols, "method")
  }
  
  # If symbols is a non-numeric vector (e.g. character), convert to factor then numeric
  if(!is.numeric(symbols)) {
    symbols <- as.numeric(as.factor(symbols))
  }
  
  n <- length(symbols)
  
  # Calculate effective length after embedding
  effective_length <- n - (embedding_dimension - 1) * time_delay
  
  if(effective_length <= 0) {
    stop("Time series too short for the chosen embedding parameters")
  }
  
  # Create state vectors using proper embedding
  state_vectors <- list()
  for(i in 1:effective_length) {
    # Create state vector with proper embedding
    if(embedding_dimension == 1) {
      state_vectors[[i]] <- symbols[i]
    } else {
      indices <- i + (0:(embedding_dimension-1)) * time_delay
      state_vectors[[i]] <- symbols[indices]
    }
  }
  
  # Create a binary recurrence matrix (1 = match, 0 = no match)
  binary_rm <- matrix(0, nrow = effective_length, ncol = effective_length)
  symbol_rm <- matrix(NA, nrow = effective_length, ncol = effective_length)
  
  # Fill the matrix comparing embedded states
  for(i in 1:effective_length) {
    for(j in 1:effective_length) {
      if(embedding_dimension == 1) {
        # For single values, just check equality
        if(!is.na(state_vectors[[i]]) && !is.na(state_vectors[[j]]) &&
           state_vectors[[i]] == state_vectors[[j]]) {
          binary_rm[i, j] <- 1
          symbol_rm[i, j] <- state_vectors[[i]]
        }
      } else {
        # For embedded vectors, check if all values match
        if(!any(is.na(state_vectors[[i]])) && !any(is.na(state_vectors[[j]])) &&
           all(state_vectors[[i]] == state_vectors[[j]])) {
          binary_rm[i, j] <- 1
          symbol_rm[i, j] <- state_vectors[[i]][1]  # Use first symbol as identifier
        }
      }
    }
  }
  
  # Convert to data frame for plotting
  recurrence_indices <- which(binary_rm == 1, arr.ind = TRUE)
  if(nrow(recurrence_indices) == 0) {
    return(ggplot2::ggplot() +
             ggplot2::labs(title = "No recurrence points found",
                           subtitle = "Check your symbolization parameters") +
             ggplot2::theme_minimal())
  }
  
  # Create data frame for plotting
  plot_data <- data.frame(
    y = recurrence_indices[, 1],
    x = recurrence_indices[, 2],
    symbol = sapply(1:nrow(recurrence_indices), function(i) {
      row <- recurrence_indices[i, 1]
      col <- recurrence_indices[i, 2]
      return(symbol_rm[row, col])
    })
  )
  
  # Get unique symbols for coloring
  unique_symbols <- sort(unique(plot_data$symbol))
  num_symbols <- length(unique_symbols)
  
  # Get appropriate labels based on method (if not provided by user)
  if(is.null(symbol_labels)) {
    if(!is.null(method)) {
      # Try to get num_symbols from attributes if available
      attr_num_symbols <- attr(symbols, "num_symbols")
      if(!is.null(attr_num_symbols)) {
        all_labels <- get_symbol_labels(method, attr_num_symbols)
      } else {
        all_labels <- get_symbol_labels(method, num_symbols)
      }
      # Only use the labels for symbols that actually appear
      # Symbols are 0-indexed, so add 1 to get label position
      symbol_labels <- all_labels[unique_symbols + 1]
    } else {
      # Generic labels if no method available
      symbol_labels <- paste("Symbol", unique_symbols)
    }
  } else if(length(symbol_labels) < num_symbols) {
    # If not enough labels provided, extend
    original_labels <- symbol_labels
    symbol_labels <- character(num_symbols)
    symbol_labels[1:length(original_labels)] <- original_labels
    for(i in (length(original_labels) + 1):num_symbols) {
      symbol_labels[i] <- paste("Symbol", unique_symbols[i])
    }
  }
  
  # Create axis labels for the embedded space
  if(is.null(axis_labels)) {
    axis_labels <- 1:effective_length
  } else if(length(axis_labels) != effective_length) {
    warning("Number of labels doesn't match effective dimensions. Using default labels.")
    axis_labels <- 1:effective_length
  }
  
  # Define theme-specific parameters
  theme_palettes <- list(
    light = list(
      diagonal = "#e74c3c",
      bg = ggplot2::theme_light() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "white"),
          plot.background = ggplot2::element_rect(fill = "white"),
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    dark = list(
      diagonal = "#e74c3c",
      bg = ggplot2::theme_dark() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "#222222"),
          plot.background = ggplot2::element_rect(fill = "#333333"),
          panel.grid.minor = ggplot2::element_blank(),
          plot.title = ggplot2::element_text(color = "white"),
          axis.title = ggplot2::element_text(color = "white"),
          axis.text = ggplot2::element_text(color = "white")
        )
    ),
    minimal = list(
      diagonal = "#e74c3c",
      bg = ggplot2::theme_minimal() +
        ggplot2::theme(
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    scientific = list(
      diagonal = "red",
      bg = ggplot2::theme_bw() +
        ggplot2::theme(
          panel.grid.minor = ggplot2::element_blank()
        )
    ),
    bold = list(
      diagonal = "#D81B60",
      bg = ggplot2::theme_bw() +
        ggplot2::theme(
          panel.background = ggplot2::element_rect(fill = "white", color = "black", linewidth = 1.2),
          plot.background = ggplot2::element_rect(fill = "white"),
          panel.grid.major = ggplot2::element_line(color = "gray80", linewidth = 0.8),
          panel.grid.minor = ggplot2::element_blank(),
          plot.title = ggplot2::element_text(face = "bold", size = 14, hjust = 0.5),
          axis.title = ggplot2::element_text(face = "bold", size = 12),
          axis.text = ggplot2::element_text(face = "bold", size = 10),
          axis.line = ggplot2::element_line(linewidth = 1.2),
          axis.ticks = ggplot2::element_line(linewidth = 1.2)
        )
    ),
    void = list(
      diagonal = "#e74c3c",
      bg = ggplot2::theme_void() +
        ggplot2::theme(
          plot.background = ggplot2::element_rect(fill = "white", color = NA),
          plot.title = ggplot2::element_text(hjust = 0.5, margin = ggplot2::margin(b = 15)),
          plot.margin = ggplot2::margin(15, 15, 10, 15),
          legend.position = "right"  # Keep legend for symbol colors
        )
    )
  )
  
  # Select theme parameters
  if(!theme %in% names(theme_palettes)) {
    warning("Unknown theme '", theme, "'. Using 'light' theme.")
    theme <- "light"
  }
  tp <- theme_palettes[[theme]]
  
  # Override diagonal color if specified
  if(!is.null(diagonal_color)) {
    tp$diagonal <- diagonal_color
  }
  
  # If no symbol colors provided, generate some
  if(is.null(symbol_colors)) {
    # Use warm, saturated rainbow colors
    symbol_colors <- rainbow(num_symbols, s = 0.8, v = 0.9, start = 0, end = 0.85)
  } else if(length(symbol_colors) < num_symbols) {
    # If not enough colors provided, recycle
    symbol_colors <- rep(symbol_colors, length.out = num_symbols)
  }
  
  # Create a named color vector for mapping
  names(symbol_colors) <- as.character(unique_symbols)
  
  # Create the diagonal data separately
  diag_df <- data.frame(x = 1:effective_length, y = 1:effective_length)
  
  # Create the plot with colored points by symbol
  p <- ggplot2::ggplot() +
    ggplot2::geom_point(data = plot_data,
                        ggplot2::aes(x = x, y = y, color = factor(symbol)),
                        shape = point_shape,
                        size = point_size,
                        alpha = alpha)
  
  # Apply the color scale for symbols with proper labels
  p <- p + ggplot2::scale_color_manual(
    values = symbol_colors,
    labels = symbol_labels,
    name = "Symbol"
  )
  
  # Add diagonal line if requested - as a separate layer
  if(highlight_diagonal) {
    p <- p + ggplot2::geom_line(data = diag_df,
                                ggplot2::aes(x = x, y = y),
                                color = tp$diagonal,
                                size = 0.8,
                                alpha = 0.8)
  }
  
  # Add axis labels and title
  embedding_subtitle <- ifelse(embedding_dimension > 1,
                               paste0(" (Embedding: ", embedding_dimension,
                                      ", Delay: ", time_delay, ")"), "")
  
  p <- p + ggplot2::labs(
    title = title,
    subtitle = embedding_subtitle,
    x = paste0("Time (", time_unit, ")"),
    y = paste0("Time (", time_unit, ")")
  )
  
  # Apply theme
  p <- p + tp$bg
  
  # For void theme, we skip axis customization completely
  if(theme != "void") {
    p <- p + ggplot2::theme(
      plot.title = ggplot2::element_text(hjust = 0.5),
      panel.grid.major = if(grid) ggplot2::element_line() else ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank()
    )
    
    # Set appropriate axis ticks
    if(effective_length <= 50) {
      # For small matrices, show all ticks
      p <- p + ggplot2::scale_x_continuous(breaks = 1:effective_length, labels = axis_labels) +
        ggplot2::scale_y_continuous(breaks = 1:effective_length, labels = axis_labels)
    } else {
      # For larger matrices, show ~10 ticks
      tick_count <- min(10, effective_length)
      tick_positions <- round(seq(1, effective_length, length.out = tick_count))
      p <- p + ggplot2::scale_x_continuous(breaks = tick_positions,
                                           labels = axis_labels[tick_positions]) +
        ggplot2::scale_y_continuous(breaks = tick_positions,
                                    labels = axis_labels[tick_positions])
    }
  } else {
    # For void theme, ensure there are no axes or grid lines
    # Just add the title if specified
    if(title != "") {
      p <- p + ggplot2::labs(title = title)
    }
  }
  
  return(p)
}