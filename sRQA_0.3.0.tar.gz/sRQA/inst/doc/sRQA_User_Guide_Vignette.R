## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>", 
  echo=T,
  fig.width = 8,
  fig.height = 6,
  out.width = "100%"
)

## ----setup--------------------------------------------------------------------
library(sRQA)
library(ggplot2)

## ----echo=T-------------------------------------------------------------------
# generate our stochastic (noise) time series 
ts_noise = rnorm(200)

# generate a periodic time series 
t <- seq(0, 4*pi, length.out = 200)
ts_periodic <- sin(t)  

# generate a chaotic time series 
lorenz <- function(x, y, z, s=10, r=28, b=8/3) {
  dx <- s*(y - x)
  dy <- x*(r - z) - y
  dz <- x*y - b*z
  c(dx, dy, dz)
}
x <- y <- z <- numeric(200)
x[1] <- y[1] <- z[1] <- 1
dt <- 0.01
for(i in 2:200) {
  derivs <- lorenz(x[i-1], y[i-1], z[i-1])
  x[i] <- x[i-1] + derivs[1]*dt
  y[i] <- y[i-1] + derivs[2]*dt
  z[i] <- z[i-1] + derivs[3]*dt
}
ts_chaotic <- x
#visualize
par(mfrow = c(3, 1), mar = c(2, 4, 2, 1))
plot(ts_noise, type = "l", main = "Stochastic (Noise)", ylab = "Value")
plot(ts_periodic, type = "l", main = "Periodic", ylab = "Value")
plot(ts_chaotic, type = "l", main = "Chaotic (Lorenz)", ylab = "Value")


## ----echo=T-------------------------------------------------------------------
# apply symbolize_ts() function to symbolize the periodic signal 
quant_symbols = sRQA::symbolize_ts(ts_periodic, method="quantiles", num_symbols=5, visualize=T)

## ----echo=T-------------------------------------------------------------------
# apply symbolize_ts() function to symbolize the periodic signal 
ord_symbols = sRQA::symbolize_ts(ts_periodic, method="ordinal_pattern", window_size=3, num_symbols=6, visualize=T)

## ----echo=T-------------------------------------------------------------------
# apply symbolize_ts() function to symbolize the periodic signal 
shape_symbols = sRQA::symbolize_ts(ts_periodic, method="rle", window_size=10, num_symbols=8, visualize=T)

## -----------------------------------------------------------------------------
# Symbolize the stochastic time series
noise_symbols <- sRQA::symbolize_ts(ts_noise, method="quantiles", num_symbols=5, visualize = T)

# Create recurrence matrix
rm_noise <- sRQA::symbolic_recurrence_matrix(noise_symbols, embedding_dimension=1, time_delay=1)

# Visualize recurrence plot
sRQA::symbol_recurrence_plot(noise_symbols, title="Symbolic Recurrence Plot: Stochastic System")

# Calculate RQA metrics
rqa_noise <- sRQA::quant_rqa(rm_noise)
print(rqa_noise)

## -----------------------------------------------------------------------------
# Symbolize the periodic time series
periodic_symbols <- sRQA::symbolize_ts(ts_periodic, method="quantiles", num_symbols=5, visualize = T)

# Create recurrence matrix
rm_periodic <- sRQA::symbolic_recurrence_matrix(periodic_symbols, embedding_dimension=1, time_delay=1)

# Visualize recurrence plot
sRQA::symbol_recurrence_plot(periodic_symbols, title="Symbolic Recurrence Plot: Periodic System")

# Calculate RQA metrics
rqa_periodic <- sRQA::quant_rqa(rm_periodic)
print(rqa_periodic)

## -----------------------------------------------------------------------------
# Symbolize the chaotic time series
chaotic_symbols <- sRQA::symbolize_ts(ts_chaotic, method="quantiles", num_symbols=5, visualize = T)

# Create recurrence matrix
rm_chaotic <- sRQA::symbolic_recurrence_matrix(chaotic_symbols, embedding_dimension=1, time_delay=1)

# Visualize recurrence plot
sRQA::symbol_recurrence_plot(chaotic_symbols, title="Symbolic Recurrence Plot: Chaotic System")

# Calculate RQA metrics
rqa_chaotic <- sRQA::quant_rqa(rm_chaotic)
print(rqa_chaotic)

## -----------------------------------------------------------------------------
rqa_df <- data.frame(
  System = c("Noise", "Periodic", "Chaotic"),
  DET = c(rqa_noise$DET, rqa_periodic$DET, rqa_chaotic$DET),
  L = c(rqa_noise$L, rqa_periodic$L, rqa_chaotic$L),
  Lmax = c(rqa_noise$Lmax, rqa_periodic$Lmax, rqa_chaotic$Lmax),
  DIV = c(rqa_noise$DIV, rqa_periodic$DIV, rqa_chaotic$DIV),
  ENTR = c(rqa_noise$ENTR, rqa_periodic$ENTR, rqa_chaotic$ENTR),
  LAM = c(rqa_noise$LAM, rqa_periodic$LAM, rqa_chaotic$LAM),
  TT = c(rqa_noise$TT, rqa_periodic$TT, rqa_chaotic$TT),
  Vmax = c(rqa_noise$Vmax, rqa_periodic$Vmax, rqa_chaotic$Vmax),
  VENTR = c(rqa_noise$VENTR, rqa_periodic$VENTR, rqa_chaotic$VENTR),
  MRT = c(rqa_noise$MRT, rqa_periodic$MRT, rqa_chaotic$MRT),
  RTE = c(rqa_noise$RTE, rqa_periodic$RTE, rqa_chaotic$RTE),
  NMPRT = c(rqa_noise$NMPRT, rqa_periodic$NMPRT, rqa_chaotic$NMPRT),
  TREND = c(rqa_noise$TREND, rqa_periodic$TREND, rqa_chaotic$TREND)
)

rqa_long <- reshape(rqa_df,
                    direction = "long",
                    varying = names(rqa_df)[-1],
                    v.names = "Value",
                    timevar = "Measure",
                    times = names(rqa_df)[-1],
                    idvar = "System")
rownames(rqa_long) <- NULL

rqa_long$System <- factor(rqa_long$System, levels = c("Noise", "Periodic", "Chaotic"))

# Set system order
rqa_long$System <- factor(rqa_long$System, levels = c("Noise", "Periodic", "Chaotic"))

# Plot
ggplot(rqa_long, aes(x = System, y = Value, fill = System)) +
  geom_col() +
  facet_wrap(~ Measure, scales = "free_y") +
  scale_fill_brewer(palette = "Set2") +
  theme_minimal() +
  theme(
    legend.position = "none",
    strip.text = element_text(face = "bold"),
    plot.title = element_text(hjust = 0.5)
  ) +
  labs(title = "Regime Comparison with sRQA", x = NULL, y = NULL)

